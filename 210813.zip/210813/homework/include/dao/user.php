<?php
class AdminSql
{
	var $seq;
	var $userId	;
	var $userPw	;
    var $admId;
    var $admPw;
	var $regDate;
	var $regId;
	var $isUse;
	
	var $ssId;
	var $isPass;
	var $conIp;

	// 관리자 리스트
	function PageLs ($pWhere, $pSearchKey, $pSearchValue, $pPage, $pPageSize, $pConnect) 
	{	
		$Sql="";
		$mWhere="";

		if($pWhere) $mWhere = $pWhere;
		
		if($pSearchValue!="") {
			if($mWhere) $mWhere.= " and";
			else $mWhere.= "where";		    
				switch($pSearchKey)
				{
					case 1:
						$mWhere.=" user_id like '%$pSearchValue%'";
						break;

					case 2:
						$mWhere.=" user_nm like '%$pSearchValue%'";
						break;
					case 3:
						$mWhere.=" (user_id like '%$pSearchValue%' or user_nm like '%$pSearchValue%') ";
						break;
				}
		}	
		else{
		//	if (adminSuperUser($_SESSION[SS_ADM_GBN])){
				//$mWhere.= "";					
		//	}else{
				//$mWhere.= " where user_id <> 'root' AND user_id <> 'nexmedia' ";	
			//}
		}

		$Sql = "select count(*) from member $mWhere";
		$Sql_que = @mysqli_query($pConnect, $Sql);
		$Result = @mysqli_fetch_row($Sql_que);
		$CountAll=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		$ResultPage = new stdClass();
		$ResultPage = new PageOut($pPageSize, $CountAll, $pPage, 10);

		$Sql = " select seq, user_id, user_pw, reg_date, reg_id, is_use ";
		$Sql.= " from member $mWhere " ;

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->admId = stripcslashes($Result["user_id"]);
			$ResultValue[$i]->admPw = stripcslashes($Result["user_pw"]);
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);

		unset($Sql_que);
		
		//echo $Sql;
		//$ResultPage = new stdClass();
		$ResultPage->mData = $LsResult;
		return $ResultPage;
	} // end function


	// 사용자 상세조회
	function SelectWithSeq ($pSeq, $pConnect) 
	{	
		$Sql = " select seq, user_id, user_pw, reg_date,reg_id, is_use, ";
		$Sql.= " from member where seq = $pSeq " ;
		$LsResult = array();
      $Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->admId = stripcslashes($Result["user_id"]);
			$ResultValue[$i]->admPw = stripcslashes($Result["user_pw"]);			
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);			
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
       	unset($Sql_que);

		return $LsResult;
	} // end function

	function SelectMaxSeq ($pConnect) 
	{	
		$Sql = " select ifnull(max(seq)+1, 1) as max_seq from member ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $maxSeq;
	} // end function

	
	// 관리자 접속로그
	function AdminLogInsert($pConnect)
	{
		$Sql = " insert into user_log (ss_id, user_id, user_pw, is_pass, conn_date, conn_ip, log_out)";
		$Sql.= " values (";
		$Sql.= "'".$this->ssId."' , ";
		$Sql.= "'".$this->admId."' , ";
		$Sql.= "'".$this->admPw."' , ";
		$Sql.= "'".$this->isPass."' , ";
		$Sql.= " now() ,";
		$Sql.= "'".$this->conIp."' , ";
		$Sql.= " null ) ";
      $Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);
	}
    
	function AdminInsert($pConnect)
	{
		$Sql = " insert into member (seq, user_id, user_pw, reg_date, reg_id, is_use)";
		$Sql.= " values (";
		$Sql.= "'".$this->seq."' , ";
		$Sql.= "'".$this->admId."' , ";
		$Sql.= " PASSWORD('".$this->admPw."') , ";		
		$Sql.= " now() ,";
		$Sql.= "'".$this->regId."' , ";
		$Sql.= "'".$this->isUse."' ) ";
      $Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);
	}
    /*
	// 관리자가 수정
	function AdminUpdate($pConnect)
	{
		$Sql = "update admin set ";
		$Sql.= " user_nm='".$this->admNm."' , ";
		if (!is_empty($this->admPw)) {
			$Sql.= " user_pw=password('".$this->admPw."') , ";
		}
		$Sql.= " email='".$this->admEmail."' , ";
		$Sql.= " TEL=HEX(AES_ENCRYPT('".$this->tel."', 'nexmedia')) , ";
		$Sql.= " AUTH_GBN='".$this->authGbn."' , ";
		$Sql.= " IS_USE='".$this->isUse."', ";
		$Sql.= " REG_ID='".$this->regId."' ";
		$Sql.= " WHERE SEQ=".$this->seq ;
		//echo $Sql;
		//exit;

		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);
	}
	// 본인이 수정
	function AdminSelfUpdate($pConnect)
	{
		$Sql = "update admin set ";
		$Sql.= " user_nm='".$this->admNm."' , ";
		if (!is_empty($this->admPw)) {
			$Sql.= " user_pw=password('".$this->admPw."') , ";
		}
		$Sql.= " email='".$this->admEmail."' , ";
		$Sql.= " TEL=HEX(AES_ENCRYPT('".$this->tel."', 'nexmedia')) , ";
		$Sql.= " REG_ID='".$this->regId."' ";
		$Sql.= " WHERE SEQ=".$this->seq ;
		//echo $Sql;
		//exit;

		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);
	}


	// 관리자 수정 (그룹코드수정시 업데이트 처리.)
	function CodeAdminUpdate($orgAuthGbn, $pConnect)
	{
		$Sql = "update admin set ";
		$Sql.= " auth_gbn = '".$this->authGbn."'";
		$Sql.= " where auth_gbn = '".$orgAuthGbn."'" ;
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		unset($Sql_que);
	}

	// 관리자 삭제
	function AdminDelete($pSeq, $pConnect)
	{
		// 권한삭제
		$Sql = " delete from admin_group_auth where admin_menu_seq='$pSeq'";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);

		// 계정삭제.
		$Sql = " delete from admin where seq='$pSeq'";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		unset($Sql_que);
	}
*/
	// 중복 체크.
	function SelectDup ($userId, $pConnect) 
	{	
		$Sql = " select count(*) from admin where user_id='$admId'";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		$Result = @mysqli_fetch_row($Sql_que);
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $Result;
	} 
	
	// 로그인.
	function SelectAdminLogin($pConnect) 
	{	
		$Sql = " select seq, user_id, user_pw from member where user_id='".$this->admId."' and user_pw=password('".$this->admPw."') and is_use='y'";
		echo "<br>SelectAdminLogin= ".$Sql." __<br>";
		//exit;

		$LsResult = array();
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		
		//$Result = @mysqli_fetch_row($Sql_que);
		//echo mysql_affected_rows() . "<br/>";
		//echo $Result["user_id"] . "<br/>";

		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->admId = stripcslashes($Result["user_id"]);
			$ResultValue[$i]->admPw = stripcslashes($Result["user_pw"]);			
			$LsResult[$i] = $ResultValue[$i];
			
		}		
		//echo $Sql . "<br/>";
		
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;
	} 

	// 본인정보수정.
	function SelectAdminSelfModify($pConnect) 
	{	
		$Sql = " select seq, user_id, user_pw, user_nm, auth_gbn from member where user_id='".$this->admId."' and user_pw=password('".$this->admPw."') and is_use='Y'";
		$LsResult = array();
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		
		//$Result = @mysqli_fetch_row($Sql_que);
		//echo mysql_affected_rows() . "<br/>";
		//echo $Result["user_id"] . "<br/>";

		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->admId = stripcslashes($Result["user_id"]);
			$ResultValue[$i]->admPw = stripcslashes($Result["user_pw"]);
			$ResultValue[$i]->admNm = stripcslashes($Result["user_nm"]);
			$ResultValue[$i]->authGbn = stripcslashes($Result["AUTH_GBN"]);
			$LsResult[$i] = $ResultValue[$i];
			
		}		
		//echo $Sql . "<br/>";
		
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;
	} 

	// 접근가능한 IP 확인.
	function SelectAdminConfigIp ($pConnect) 
	{	
		$Sql = "SELECT COUNT(*) FROM admin_config_ip WHERE ip='".$this->conIp."' and is_use='Y'";
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		$Result = @mysqli_fetch_row($Sql_que);
		//echo $Result[0];
		//exit;
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $Result;
	} 
	
	function SelectLoginFailCount ($pConnect) 
	{	
		$Sql = "SELECT ifnull(PW_FAIL_CNT,0) FROM member WHERE user_id='".$this->admId."'";
		echo "<br><br>SelectLoginFailCount = ".$Sql;
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		$Result = @mysqli_fetch_row($Sql_que);
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $Result;
	} 

	// 이미 로그인한 정보삭제 후 새로 입력..
	function duplicationProc($pConnect) 
	{	
		$Sql = "delete from admin_duplication where seq in (select seq from (select seq from admin_duplication where admin_id='".$this->admId."') A) " ; 
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		unset($Sql_que);

		$Sql = "select ifnull(max(seq)+1, 1) as max_seq from admin_duplication ";
		$Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		$Sql = "insert into admin_duplication (seq, admin_id, ss_id, ip, login_time)";
		$Sql.= " values (";
		$Sql.= "'".$maxSeq."' , ";
		$Sql.= "'".$this->admId."' , ";
		$Sql.= "'".$this->ssId."' , ";
		$Sql.= "'".$this->conIp."' , ";
		$Sql.= " now() ";
		$Sql.= " ) ";
      $Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		unset($Sql_que);
	} 

	// 다른사람이 로그인을 했는지 확인.
	function duplicationCheck($pConnect) 
	{	
		$Sql = "select count(*) from admin_duplication where admin_id='".$this->admId."' and ss_id='".$this->ssId."'";
      $Sql_que =  @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());  
		$Result = @mysqli_fetch_row($Sql_que);
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $Result;

	} 

} // end class	
?>