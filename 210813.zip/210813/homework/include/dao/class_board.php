<?php
class BoardSql
{
	var $seq;
	var $boardId;
	var $subject;
	var $content;
	var $readCnt;
	var $isTop;
	var $regDate;
	var $regId;
	var $regIp;
	var $isOpen;

	// 첨부파일
	var $pSeq;
	var $attGbn;
	var $fileOrgNm;
	var $fileSvcNm;
	var $fSize;
	var $thumbNm;
	var $admNm;

	function PageLs ($pBoardId, $pWhere, $pSearchKey, $pSearchValue, $pPage, $pPageSize, $pConnect)
	{
		$Sql="";
		$mWhere="where 1";

		if($pWhere) $mWhere = $pWhere;

        // 검색어가있을경우 실행
		if($pSearchValue!="") {
			if($mWhere) $mWhere.= " and";
			else $mWhere.= "where";
				switch($pSearchKey)
				{
					case 1:
						$mWhere.=" SUBJECT LIKE '%$pSearchValue%'";
						break;
					case 2:
						$mWhere.=" CONTENT LIKE '%$pSearchValue%'";
						break;
					case 3:
						$mWhere.=" (SUBJECT LIKE '%$pSearchValue%' OR CONTENT LIKE '%$pSearchValue%') ";
						break;
				}
		}
        // 검색어가있을경우 실행 끝

        // 게시글 개수 조회
		$Sql = "SELECT COUNT(*) FROM board $mWhere AND IS_TOP='N'";        
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		$Result = @mysqli_fetch_row($Sql_que);
		$CountAll=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
        // 게시글 개수 조회 끝
		//echo $Sql;
		$ResultPage = new stdClass();
		$ResultPage = new PageOut($pPageSize, $CountAll, $pPage, 10);

		$Sql = "SELECT SEQ, BOARD_ID, SUBJECT, CONTENT, READ_CNT, IS_TOP, REG_DATE, REG_ID, REG_IP,  IS_OPEN FROM board $mWhere AND IS_TOP='N'  ORDER BY REG_DATE DESC, SEQ DESC";						
        
		$Sql.= " LIMIT $ResultPage->mLimitStart, $ResultPage->mSizePage";
		// echo "리스트=". $Sql."<br><br>";
		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
        
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->boardId		= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[$i]->subject	= stripcslashes($Result["SUBJECT"]);
			$ResultValue[$i]->content	= stripcslashes($Result["CONTENT"]);
			$ResultValue[$i]->readCnt	= stripcslashes($Result["READ_CNT"]);
			$ResultValue[$i]->isTop	= stripcslashes($Result["IS_TOP"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["REG_DATE"]);
			$ResultValue[$i]->regId	= stripcslashes($Result["REG_ID"]);
			$ResultValue[$i]->regIp		= stripcslashes($Result["REG_IP"]);			
			$ResultValue[$i]->isOpen	= stripcslashes($Result["IS_OPEN"]);			
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		$ResultPage->mData = $LsResult;
		return $ResultPage;
	} // end function



	// 중요공지사항 불러오기.
	function IsTopLs ($pBoardId, $pWhere, $pConnect)
	{
        
		$mWhere= "where 1" ;
        
		$Sql = "SELECT SEQ, BOARD_ID, SUBJECT, /*CONTENT,*/ READ_CNT, IS_TOP, REG_DATE, REG_ID, REG_IP, IS_OPEN FROM board $mWhere AND IS_TOP='Y' ORDER BY REG_DATE DESC, SEQ DESC";
        
        //echo "<br>공지 불러오기".$Sql;
		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->boardId		= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[$i]->subject	= stripcslashes($Result["SUBJECT"]);
			$ResultValue[$i]->readCnt	= stripcslashes($Result["READ_CNT"]);
			$ResultValue[$i]->isTop	= stripcslashes($Result["IS_TOP"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["REG_DATE"]);
			$ResultValue[$i]->regId	= stripcslashes($Result["REG_ID"]);
			$ResultValue[$i]->regIp		= stripcslashes($Result["REG_IP"]);			
			$ResultValue[$i]->isOpen	= stripcslashes($Result["IS_OPEN"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		$ResultPage = new stdClass();
		$ResultPage->mData = $LsResult;
		return $ResultPage;
	} // end function

	function SelectWithSeq ($pSeq, $pConnect)
	{
		$Sql = "SELECT * FROM board WHERE SEQ = $pSeq";

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->boardId		= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[$i]->subject	= stripcslashes($Result["SUBJECT"]);
			$ResultValue[$i]->content	= stripcslashes($Result["CONTENT"]);
			$ResultValue[$i]->readCnt	= stripcslashes($Result["READ_CNT"]);
			$ResultValue[$i]->isTop	= stripcslashes($Result["IS_TOP"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["REG_DATE"]);
			$ResultValue[$i]->regId	= stripcslashes($Result["REG_ID"]);
			$ResultValue[$i]->regIp		= stripcslashes($Result["REG_IP"]);			
			$ResultValue[$i]->isOpen	= stripcslashes($Result["IS_OPEN"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		return $LsResult;

	} // end function

	function SelectMaxSeq ($pConnect)
	{
		$Sql = "SELECT IFNULL(MAX(SEQ)+1, 1) AS MAX_SEQ FROM board";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		return $maxSeq;

	} // end function

	function Insert($maxSeq, $pConnect)
	{        
		$Sql = "INSERT INTO board (SEQ, BOARD_ID, SUBJECT, CONTENT, READ_CNT, IS_TOP, REG_DATE, REG_ID, REG_IP, IS_OPEN)";
		$Sql.= " VALUES (";
		$Sql.= $maxSeq;
		$Sql.= ", '".$this->boardId;
		$Sql.= "','".$this->subject;
		$Sql.= "','".$this->content;
		$Sql.= "', 0 ";
		$Sql.= ",'".$this->isTop;
		$Sql.= "',now()";
		$Sql.= ",'".$this->regId;
		$Sql.= "','".$this->regIp;		
		$Sql.= "','".$this->isOpen;
		$Sql.= "')";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
		//echo ($Sql);

    }

	function Update($pSeq, $pConnect)
	{
		$Sql = " UPDATE board SET ";
		$Sql.= " BOARD_ID	='".$this->boardId."'";
		$Sql.= ", SUBJECT	='".$this->subject."'";
		$Sql.= ", CONTENT	='".$this->content."'";
		$Sql.= ", IS_TOP		='".$this->isTop."'";
		$Sql.= ", REG_DATE		= now() ";
		$Sql.= ", REG_ID		='".$this->regId."'";
		$Sql.= ", REG_IP		='".$this->regIp."'";		
		$Sql.= ", IS_OPEN		='".$this->isOpen."'";
		$Sql.= " WHERE SEQ = $pSeq";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
		//echo $Sql;
    }

	function UpdateSetReadCnt($pSeq, $pConnect)
	{
		$Sql = "UPDATE board SET READ_CNT=ifnull(READ_CNT, 0)+1 WHERE SEQ = $pSeq";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
		//echo $Sql;
		//exit;
	}

	function UpdateSetIsTop($pSeq, $pPlace, $pConnect)
	{
		$Sql = "UPDATE board SET IS_TOP='$pPlace' WHERE SEQ = $pSeq";
      $Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
   }

	function BoardDelete($pSeq, $pConnect)
	{
		$Sql = "DELETE FROM board WHERE SEQ = $pSeq";
      $Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
   }

	function SelectWithNextPre ($pBoardId, $pSeq, $pIsTop, $pConnect)
	{
		$LsResult = array();
		$ResultValue = array();

		$ResultValue[0] = "";
		$ResultValue[1] = "";

		// 이전글
		$mWhere = " WHERE BOARD_ID='$pBoardId' AND (IS_TOP = '$pIsTop' and SEQ > $pSeq)";
		$Sql = "SELECT SEQ, BOARD_ID, SUBJECT, REG_DATE FROM board $mWhere";
		$Sql.= " ORDER BY SEQ LIMIT 1";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[0] = new stdClass();
			$ResultValue[0]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[0]->boardId	= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[0]->subject	= stripcslashes($Result["SUBJECT"]);
			$ResultValue[0]->regDate	= stripcslashes($Result["REG_DATE"]);
			//$LsResult[0] = $ResultValue[0];
		}
		$LsResult[0] = $ResultValue[0];
		unset($Sql_que);

		//다음글
		$mWhere = " WHERE BOARD_ID='$pBoardId' AND (IS_TOP = '$pIsTop' and SEQ < $pSeq)";
		$Sql = "SELECT SEQ, BOARD_ID, SUBJECT, REG_DATE FROM board $mWhere";
		$Sql.= " ORDER BY SEQ DESC LIMIT 1";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[1] = new stdClass();
			$ResultValue[1]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[1]->boardId	= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[1]->subject	= stripcslashes($Result["SUBJECT"]);
			$ResultValue[1]->regDate	= stripcslashes($Result["REG_DATE"]);
		}
		$LsResult[1] = $ResultValue[1];

		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		return $LsResult;

   }

	/*
	첨부파일 하나.
	*/
	function FileDetail ($seq, $pSeq, $pBoardId, $pAttGbn, $pConnect)
	{
		$Sql = "SELECT SEQ, P_SEQ, BOARD_ID, ATT_GBN, FILE_ORG_NM, FILE_SVC_NM, THUMB_NM, FILE_SIZE, READ_CNT, REG_DATE, REG_ID, REG_IP FROM board_file WHERE SEQ=$seq AND P_SEQ=$pSeq AND BOARD_ID='$pBoardId' AND ATT_GBN='$pAttGbn' ";
		$FileResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->pSeq		= stripcslashes($Result["P_SEQ"]);
			$ResultValue[$i]->boardId	= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[$i]->attGbn	= stripcslashes($Result["ATT_GBN"]);
			$ResultValue[$i]->fileOrgNm	= stripcslashes($Result["FILE_ORG_NM"]);
			$ResultValue[$i]->fileSvcNm	= stripcslashes($Result["FILE_SVC_NM"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["THUMB_NM"]);
			$ResultValue[$i]->fSize		= stripcslashes($Result["FILE_SIZE"]);
			$ResultValue[$i]->readCnt	= stripcslashes($Result["READ_CNT"]);
			$ResultValue[$i]->thumbNm	= stripcslashes($Result["REG_DATE"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["REG_ID"]);
			$ResultValue[$i]->regIp		= stripcslashes($Result["REG_IP"]);
			$FileResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		//echo $Sql . "<br />";
		//$ResultPage->mData = $FileResult;
		//return $ResultPage;
		return $FileResult;
	} // end function

	/*
	첨부파일 저장.
	*/
	function FileInsert($pConnect)
	{
		$Sql = "SELECT IFNULL(MAX(SEQ)+1, 1) AS MAX_SEQ FROM board_file";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		$Sql = " INSERT INTO board_file (SEQ, P_SEQ, BOARD_ID, ATT_GBN, FILE_ORG_NM, FILE_SVC_NM, THUMB_NM, FILE_SIZE, READ_CNT, REG_DATE, REG_ID, REG_IP) ";
		$Sql.= " VALUES (" ;
		$Sql.= $maxSeq ;
		$Sql.= ",'".$this->pSeq ;
		$Sql.= "','".$this->boardId ;
		$Sql.= "','".$this->attGbn ;
		$Sql.= "','".$this->fileOrgNm ;
		$Sql.= "','".$this->fileSvcNm ;
		$Sql.= "','".$this->thumbNm ;
		$Sql.= "','".$this->fSize ;
		$Sql.= "', 0" ;
		$Sql.= ",now() " ;
		$Sql.= ",'".$this->regId ;
		$Sql.= "','".$this->regIp ;
		$Sql.= "') " ;
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);

		//echo ($Sql);
    }

	/*
	첨부파일 삭제.
	*/
	function FileDelete($pSeq, $pConnect)
	{
		$Sql = "DELETE FROM board_file WHERE SEQ = $pSeq" ;
      $Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
   }

	/*
	첨부파일 수정.
	*/
	function FileUpdate($pSeq, $pConnect)
	{
		$Sql = " UPDATE board_file SET ";
		$Sql.= " ATT_GBN	='".$this->attGbn."'" ;
		$Sql.= ", FILE_ORG_NM	='".$this->fileOrgNm."'" ;
		$Sql.= ", FILE_SVC_NM	='".$this->fileSvcNm."'" ;
		$Sql.= ", THUMB_NM		='".$this->thumbNm."'" ;
		$Sql.= ", FILE_SIZE		='".$this->fSize."'" ;
		$Sql.= ", REG_DATE		= now() " ;
		$Sql.= ", REG_ID		='".$this->regId."'" ;
		$Sql.= ", REG_IP		='".$this->regIp."'" ;
		$Sql.= " WHERE SEQ = $pSeq" ;
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
    }

	/*
	첨부파일 조회수 업데이트.
	*/
	function FileReadUpdate($pSeq, $pConnect)
	{
		$Sql = " UPDATE board_file SET " ;
		$Sql.= " READ_CNT	= READ_CNT + 1 " ;
		$Sql.= " WHERE SEQ = $pSeq" ;
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
   }
} // end class
?>
