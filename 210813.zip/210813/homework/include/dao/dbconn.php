<?php
class DBConn
{
	var $mConn;
	function DBConn()
	{
		$this->mConn = mysqli_connect('localhost', 'lmhst', 'lmhst052783@@') or die("데이터베이스 연결에 실패했습니다3..." . mysqli_error() );		
		mysqli_select_db($this->mConn, 'lmhst') or die("데이터베이스 연결에 실패했습니다4..." . mysqli_error());
	}

	function DisConnect()
	{
		@mysqli_close($this->mConn);
		$this->mConn = null;
	}
}



?>