<?php
class CodeListSql
{
	var $seq				; //순번
	var $codeGroup		; //그룹코드
	var $code			; //코드값
	var $codeNm			; //코드명
	var $info1			; //부가정보_1
	var $info2			; //부가정보_2
	var $info3			; //부가정보_3
	var $info4			; //부가정보_4
	var $info5			; //부가정보_5
	var $isUse			; //사용여부
	var $sortNum		; //정렬순서
	var $regDate		; //등록일
	var $regId			; //등록자아이디

	// 코드 리스트
	function PageLs ($pWhere, $pSearchKey, $pSearchValue, $pPage, $pPageSize, $pConnect) 
	{	
		if($pWhere) $mWhere = $pWhere;
		
		$Sql = " select count(*) from code_list $mWhere";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		$Result = @mysqli_fetch_row($Sql_que);	// 값을 꺼내오는데 [index] 숫자값을 사용 mysqli_fetch_assoc(). 필드명이나 쿼리문에 사용된 alias로 배열을 참조
		$CountAll=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		//@mysqli_close($pConnect);

		$ResultPage = new PageOut($pPageSize, $CountAll, $pPage, 10);

		$Sql = " select seq, code_group, code, code_nm, info1, info2, info3, info4, info5, is_use, sort_num, reg_date, reg_id from code_list $mWhere";
		$Sql.= " order by reg_date desc, code_group desc, sort_num desc ";
		$Sql.= " limit $ResultPage->mLimitStart, $ResultPage->mSizePage";
		
		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->codeGroup = stripcslashes($Result["code_group"]);
			$ResultValue[$i]->code = stripcslashes($Result["code"]);
			$ResultValue[$i]->codeNm = stripcslashes($Result["code_nm"]);
			$ResultValue[$i]->info1 = stripcslashes($Result["info1"]);
			$ResultValue[$i]->info2 = stripcslashes($Result["info2"]);
			$ResultValue[$i]->info3 = stripcslashes($Result["info3"]);
			$ResultValue[$i]->info4 = stripcslashes($Result["info4"]);
			$ResultValue[$i]->info5 = stripcslashes($Result["info5"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$ResultValue[$i]->sortNum = stripcslashes($Result["sort_num"]);
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);

		unset($Sql_que);
		
		//echo $Sql;
		//$ResultPage = new stdClass();
		$ResultPage->mData = $LsResult;
		return $ResultPage;
	}


	// 코드 상세조회
	function SelectWithSeq ($seq, $pConnect) 
	{	
		$Sql = " select seq, code_group, code, code_nm, info1, info2, info3, info4, info5, is_use, sort_num, reg_date, reg_id from code_list where seq = $seq";
		$LsResult = array();
      $Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
	
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->codeGroup = stripcslashes($Result["code_group"]);
			$ResultValue[$i]->code = stripcslashes($Result["code"]);
			$ResultValue[$i]->codeNm = stripcslashes($Result["code_nm"]);
			$ResultValue[$i]->info1 = stripcslashes($Result["info1"]);
			$ResultValue[$i]->info2 = stripcslashes($Result["info2"]);
			$ResultValue[$i]->info3 = stripcslashes($Result["info3"]);
			$ResultValue[$i]->info4 = stripcslashes($Result["info4"]);
			$ResultValue[$i]->info5 = stripcslashes($Result["info5"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$ResultValue[$i]->sortNum = stripcslashes($Result["sort_num"]);
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		//echo $Sql;
		@mysqli_free_result($Sql_que);
      unset($Sql_que);
		//@mysqli_close($pConnect);
		return $LsResult;
	}

	// 코드그룹 목록
	function SelectCodeGroup ($pConnect) 
	{	
		$Sql = " select code_group,info1 from code_list group by code_group, info1 ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		
		$LsResult = array();
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->codeGroup = stripcslashes($Result["code_group"]);
			$ResultValue[$i]->info1 = stripcslashes($Result["info1"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
      unset($Sql_que);
		//@mysqli_close($pConnect);
		return $LsResult;
	}

	// 특정코드그룹목록보기.
	function SelectCodeGroupList ($pConnect) 
	{	
		$Sql = " select seq, code_group, code, code_nm, info1, info2, info3, info4, info5, is_use, sort_num, reg_date, reg_id from code_list where code_group = '".$this->codeGroup."' order by sort_num ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 

		$LsResult = array();
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->codeGroup = stripcslashes($Result["code_group"]);
			$ResultValue[$i]->code = stripcslashes($Result["code"]);
			$ResultValue[$i]->codeNm = stripcslashes($Result["code_nm"]);
			$ResultValue[$i]->info1 = stripcslashes($Result["info1"]);
			$ResultValue[$i]->info2 = stripcslashes($Result["info2"]);
			$ResultValue[$i]->info3 = stripcslashes($Result["info3"]);
			$ResultValue[$i]->info4 = stripcslashes($Result["info4"]);
			$ResultValue[$i]->info5 = stripcslashes($Result["info5"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$ResultValue[$i]->sortNum = stripcslashes($Result["sort_num"]);
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;
	}


	// 특정코드 보기.
	function SelectCodeInfo ($pConnect) 
	{	
		$Sql = " select seq, code_group, code, code_nm, info1, info2, info3, info4, info5, is_use, sort_num, reg_date, reg_id from code_list where code_group = '".$this->codeGroup."' and code = '".$this->code."'   ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 

		$LsResult = array();
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->codeGroup = stripcslashes($Result["code_group"]);
			$ResultValue[$i]->code = stripcslashes($Result["code"]);
			$ResultValue[$i]->codeNm = stripcslashes($Result["code_nm"]);
			$ResultValue[$i]->info1 = stripcslashes($Result["info1"]);
			$ResultValue[$i]->info2 = stripcslashes($Result["info2"]);
			$ResultValue[$i]->info3 = stripcslashes($Result["info3"]);
			$ResultValue[$i]->info4 = stripcslashes($Result["info4"]);
			$ResultValue[$i]->info5 = stripcslashes($Result["info5"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$ResultValue[$i]->sortNum = stripcslashes($Result["sort_num"]);
			$ResultValue[$i]->regDate = stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId = stripcslashes($Result["reg_id"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;
	}


	function SelectNextSortNum ($pConnect) 
	{	
		$Sql = " select ifnull(max(sort_num)+1, 1) as max_sort from code_list where code_group = '".$this->codeGroup."' ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSort=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $maxSort;
	}


	function SelectMaxSeq ($pConnect) 
	{	
		$Sql = " select ifnull(max(seq)+1, 1) as max_seq from code_list ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $maxSeq;
	}


	function SelectMaxSortNum ($pConnect) 
	{	
		$Sql = " select ifnull(max(sort_num)+1, 1) as max_sort from code_list ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSort=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $maxSort;
	}

	// 입력
	function CodeInsert($pConnect)
	{
		$Sql = " insert into code_list (seq, code_group, code, code_nm, info1, info2, info3, info4, info5, is_use, sort_num, reg_date, reg_id)";
		$Sql.= " values (";
		$Sql.= "'".$this->seq."' , ";
		$Sql.= "'".$this->codeGroup."' , ";
		$Sql.= "'".$this->code."' , ";
		$Sql.= "'".$this->codeNm."' , ";
		$Sql.= "'".$this->info1."' , ";
		$Sql.= "'".$this->info2."' , ";
		$Sql.= "'".$this->info3."' , ";
		$Sql.= "'".$this->info4."' , ";
		$Sql.= "'".$this->info5."' , ";
		$Sql.= "'".$this->isUse."' , ";
		$Sql.= "'".$this->sortNum."' , ";
		$Sql.= " now() ,";
		$Sql.= "'".$this->regId."' ) ";
      $Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		unset($Sql_que);
		//@mysqli_close($pConnect);
	}

	// 수정
	function CodeUpdate($pConnect)
	{
		$Sql = " update code_list set ";
		$Sql.= " code_group='".$this->codeGroup."' , ";
		$Sql.= " code='".$this->code."' , ";
		$Sql.= " code_nm='".$this->codeNm."' , ";
		$Sql.= " info1='".$this->info1."' , ";
		$Sql.= " info2='".$this->info2."' , ";
		$Sql.= " info3='".$this->info3."' , ";
		$Sql.= " info4='".$this->info4."' , ";
		$Sql.= " info5='".$this->info5."' , ";
		$Sql.= " is_use='".$this->isUse."' , ";
		$Sql.= " sort_num ='".$this->sortNum."'  ";
		$Sql.= " where seq=".$this->seq ;
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		unset($Sql_que);
		//@mysqli_close($pConnect);
	}

	// 삭제
	function CodeDelete($seq, $pConnect)
	{
		$Sql = " delete from code_list where seq=$seq ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		unset($Sql_que);
		//@mysqli_close($pConnect);
	}

	// 중복 체크.
	function SelectDup ($codeGroup, $code, $codeNm, $pConnect) 
	{	
		$Sql = " select count(*) from code_list where (code_group='$codeGroup' and code='$code' and code_nm = '$codeNm') ";
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect)); 
		$Result = @mysqli_fetch_row($Sql_que);
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $Result;
	} 

}
?>




