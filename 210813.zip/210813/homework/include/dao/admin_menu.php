<?php
class AdminMenuSql
{
	var $seq;
	var $parent_Seq ;
	var $menuNm	;
	var $menuUrl;
	var $isUse;
	var $regDate;
	var $regId;
	var $sortNum;

	// 관리자메뉴 리스트
	function AdminMenuList ($pConnect, $seq) 
	{	
		$Sql = "SELECT seq, parent_seq, menu_nm, menu_url, is_use, reg_date, reg_id, sort_num FROM admin_menu WHERE parent_seq=".$seq." and is_use='Y' order by sort_num asc;";

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["seq"]);
			$ResultValue[$i]->parentSeq = stripcslashes($Result["parent_seq"]);
			$ResultValue[$i]->menuNm	= stripcslashes($Result["menu_nm"]);
			$ResultValue[$i]->menuUrl	= stripcslashes($Result["menu_url"]);
			$ResultValue[$i]->isUse		= stripcslashes($Result["is_use"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["reg_id"]);
			$ResultValue[$i]->sortNum		= stripcslashes($Result["sort_num"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		
		//echo $Sql;
		
		return $LsResult;
	}

	// 관리자메뉴 추가
	function AdminMenuAdd ($pConnect) 
	{	
		// 입력될 sort 값 구하기.
		$result = @mysqli_query($pConnect, "SELECT ifnull(max(sort_num)+1, 1) sort_num FROM admin_menu where parent_seq = ".$this->seq);
		$row = @mysqli_fetch_array($result);
		$new_order = $row['sort_num'];
		unset($result);
		
		// 입력될 seq 조회.
		$result = @mysqli_query($pConnect, "SELECT ifnull(max(seq)+1, 1) maxseq FROM admin_menu");
		$maxrow = @mysqli_fetch_array($result);
		unset($result);

		// 신규카테고리저장
		$Sql = "INSERT INTO admin_menu (seq, parent_seq, menu_nm, menu_url, is_use, reg_date, reg_id, sort_num) ".
					"VALUES (".$maxrow['maxseq'].", '".$this->seq."', '".$this->menuNm."', '".$this->menuUrl."', '".$this->isUse."', now(), '".$this->regId."', '".$new_order."')";

		$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
		unset($result);
	}

	// 선택한 관리자메뉴 수정
	function AdminMenuEdit ($pConnect) 
	{	
		// 선택된메뉴수정
		$Sql = "update admin_menu set ";
		$Sql .= " menu_nm = '".$this->menuNm."', ";
		$Sql .= "	menu_url = '".$this->menuUrl."',  ";
		$Sql .= "	is_use = '".$this->isUse."',  ";
		$Sql .= "	reg_date = now(),  ";
		$Sql .= "	reg_id = '".$this->regId."',  ";
		$Sql .= "	sort_num = '".$this->sortNum."' ";
		$Sql .= "	where seq = ".$this->seq;
			
		$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
		unset($result);
	}


	// 관리자메뉴 삭제
	function AdminMenuDel($pConnect, $seq) 
	{	
		// 현재메뉴의 하부메뉴.
		$Sql = "SELECT seq, parent_seq, menu_nm, sort_num FROM admin_menu WHERE parent_seq=".$seq;
		$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
		
		$Sql = "DELETE FROM admin_menu WHERE seq = ".$seq;
		@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
		
		while ($row = @mysqli_fetch_array($result)) {
			// 선택한 하부 메뉴삭제
			@mysqli_query($pConnect, "DELETE FROM admin_menu WHERE seq = ".$row['seq']) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
			AdminMenuSql::AdminMenuDel($pConnect, $row['seq']);
		}
		unset($result);

	}

	
	// 현재 선택한 메뉴정보 조회.
	function SelectWithSeq ($pConnect, $seq) 
	{	
		$Sql = "SELECT seq, parent_seq, menu_nm, menu_url, is_use, reg_date, reg_id, sort_num FROM admin_menu WHERE seq=".$seq;

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(mysqli_error($pConnect)); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["seq"]);
			$ResultValue[$i]->parentSeq = stripcslashes($Result["parent_seq"]);
			$ResultValue[$i]->menuNm	= stripcslashes($Result["menu_nm"]);
			$ResultValue[$i]->menuUrl	= stripcslashes($Result["menu_url"]);
			$ResultValue[$i]->isUse		= stripcslashes($Result["is_use"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["reg_id"]);
			$ResultValue[$i]->sortNum		= stripcslashes($Result["sort_num"]);
			$LsResult[$i] = $ResultValue[$i];
			//echo str_repeat(' ',$level).$row['menu_nm']. "[".$row['seq']."][".$row['parent_seq']."][".$row['sort']."]" ;
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		
		//echo $Sql;
		
		return $LsResult;
	}

	// 정렬순서변경
	function AdminMenuSort ($pConnect, $seq, $parent_Seq, $choiceSortNum, $ord) 
	{	
		if ($ord=='up'){		// 위로.

			// 바로 위
			$Sql = "select seq, sort_num from admin_menu where parent_seq=".$parent_Seq." and sort_num < ".$choiceSortNum." order by sort_num desc limit 0,1";
			$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
			$row = @mysqli_fetch_array($result);

			$targerSeq = $row['seq'];
			$targerSortNum = $row['sort_num'];

			if ($targerSeq!=''){
				$Sql = "update admin_menu set ";
				$Sql .= "	sort_num = '".$targerSortNum."' ";
				$Sql .= "	where seq = ".$seq;
				@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
				
				$Sql = "update admin_menu set ";
				$Sql .= "	sort_num = '".$choiceSortNum."' ";
				$Sql .= "	where seq = ".$targerSeq;
				@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
			}
		}
		else if ($ord=='down'){		// 아래로.

			// 바로 아래
			$Sql = "select seq, sort_num from admin_menu where parent_seq=".$parent_Seq." and sort_num > ".$choiceSortNum." order by sort_num asc limit 0,1";
			$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
			$row = @mysqli_fetch_array($result);

			$targerSeq = $row['seq'];
			$targerSortNum = $row['sort_num'];
			
			if ($targerSeq!=''){
				$Sql = "update admin_menu set ";
				$Sql .= "	sort_num = '".$targerSortNum."' ";
				$Sql .= "	where seq = ".$seq;
				@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
	
				$Sql = "update admin_menu set ";
				$Sql .= "	sort_num = '".$choiceSortNum."' ";
				$Sql .= "	where seq = ".$targerSeq;
				@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
			}
		}
		
		unset($result);	
	}

}
?>
