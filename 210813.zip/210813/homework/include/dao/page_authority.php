<?php

session_start();

class PageAuthSql
{
	var $seq	;
	var $parentSeq	;
	var $menuNm	;
	var $menuUrl	;
	var $isUse	;
	var $regDate	;
	var $regId	;
	var $sortNum	;
	var $authKindS	;
	var $authKindW	;
	var $authKindE	;
	var $authKindD	;
	var $authKindP	;
	var $authKindX	;
	var $codeGroup	;
	var $codeNm	;
	var $code	;
	var $info1	;
	var $nextSeq	;

	function PageAuthrityCheck($scriptFileName, $ssAdmId, $menuCode, $pConnect){

		$menuCode = isset($_REQUEST['menuCode']) ? $_REQUEST['menuCode'] : $_SESSION['MENU_CODE'];

		if ($menuCode==null || $menuCode==''){
			$menuCode = $_SESSION['MENU_CODE'];	
		}
		else{
			unset( $_SESSION['MENU_CODE'] );
			$_SESSION['MENU_CODE'] = $menuCode;	
		}
		$Sql = "SELECT SEQ, BOARD_ID, SUBJECT, /*CONTENT,*/ READ_CNT, IS_TOP, REG_DATE, REG_ID, REG_IP, IS_OPEN  ";
		$Sql .= "				FROM board  ";		
		$Sql .= "			 WHERE 1  ";

		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()) ;
		//echo $Sql;
		$LsResult = array();
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->menuNm = stripcslashes($Result["menu_nm"]);
			$ResultValue[$i]->menuUrl = stripcslashes($Result["menu_url"]);
			$ResultValue[$i]->isUse = stripcslashes($Result["is_use"]);
			$ResultValue[$i]->authKindS = stripcslashes($Result["auth_kind_s"]);
			$ResultValue[$i]->authKindW = stripcslashes($Result["auth_kind_w"]);
			$ResultValue[$i]->authKindE = stripcslashes($Result["auth_kind_e"]);
			$ResultValue[$i]->authKindD = stripcslashes($Result["auth_kind_d"]);
			$ResultValue[$i]->authKindP = stripcslashes($Result["auth_kind_p"]);
			$ResultValue[$i]->authKindX = stripcslashes($Result["auth_kind_x"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;			
	}
}


//if ($_SESSION["SS_ADM_ID"]==null||$_SESSION["SS_ADM_ID"]==''||$_SESSION["MENU_CODE"]==null||$_SESSION["MENU_CODE"]==''){
    /*
if ($_SESSION["SS_ADM_ID"]==null||$_SESSION["SS_ADM_ID"]==''){
	//echo "페이지 인증정보 없음.";
	echo "<script language=\"javascript\">";
	echo "alert(\"로그인이 필요합니다.\");location.href=\"/admin/main/login.php\";";
	echo "</script>";
	exit;
}
*/
//##################################################################################//
$gAuthConn = new DBConn();
$PageAuthSql = new PageAuthSql();
$pageAuthrityResult = $PageAuthSql->PageAuthrityCheck($_SERVER["SCRIPT_FILENAME"], 
	$_SESSION["SS_ADM_ID"], $_SESSION["MENU_CODE"], $gAuthConn->mConn);
$gAuthConn->DisConnect();
/*
if ($pageAuthrityResult[0]->authKindS != 'S'){
	//echo "페이지 인증정보 없음.";
	echo "<script language=\"javascript\">";
	echo "alert(\"현재메뉴의 접근권한이 없습니다.\");history.back();";
	echo "</script>";
	exit;
}
*/
//else{
//	echo $pageAuthrityResult[0]->authKindS;
//}
//#################################################################################//
?>