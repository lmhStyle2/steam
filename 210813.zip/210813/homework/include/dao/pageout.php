<?
class PageOut
{	
     var $mLimitStart;
     var $mSizePage;
     var $mListAll;
     
     var $mStartPage;
     var $mEndPage;
     var $mLastPage;
     var $mCurrPage;
     var $mPageSet;			

     function PageOut($pSizePage, $pListAll, $pCurrPage=1, $pPageSet=10 ) 
     { 

          $pLastPage = (int)($pListAll / $pSizePage); 
          if( ceil($pListAll / $pSizePage) ) $pLastPage += 1; 
          if( $pListAll==0 ) $pLastPage = 1; 
                    
          if ($pCurrPage > $pLastPage) $pCurrPage = $pLastPage; 
          elseif ($pCurrPage < 1 ) $pCurrPage = 1; 
          
          $pPrePage = $pCurrPage - 1; 
          if( $pCurrPage + 1 > $pLastPage ) $pNextPage = 0; 
          else $pNextPage = $pCurrPage + 1; 
          
          $pCurrPageImsi = ((int)($pCurrPage / $pPageSet))*$pPageSet + 1; 
          if((int)($pCurrPage % $pPageSet) == 0 ) $pStartPage = $pCurrPageImsi - $pPageSet; 
          else $pStartPage = $pCurrPageImsi;
                    
          $pEndPage = $pStartPage + $pPageSet-1; 
          if( $pEndPage > $pLastPage ) $pEndPage = $pLastPage; 
          
          $pLimitStart=($pCurrPage - 1) * $pSizePage; 

	     $this->mLimitStart=$pLimitStart;	     
	     $this->mSizePage=$pSizePage;
	     $this->mListAll=$pListAll;
	     
	     $this->mStartPage=$pStartPage;
	     $this->mEndPage=$pEndPage;
	     $this->mLastPage=$pLastPage;
	     $this->mCurrPage=$pCurrPage;
	     $this->mPageSet=$pPageSet;	     	     	     
	}
	
	/*
	<a href=\"#\" class=\"arrow\"><img src=\"/images/common/page_arrow_1.gif\" alt=\"첫페이지로\"></a>
	<a href=\"#\" class=\"arrow mr\"><img src=\"/images/common/page_arrow_2.gif\" alt=\"이전\"></a>
	<a href=\"#\" class=\"on\"><span>1</span></a>
	<a href=\"#\"><span>2</span></a>
	<a href=\"#\"><span>3</span></a>
	<a href=\"#\"><span>4</span></a>
	<a href=\"#\" class=\"arrow ml\"><img src=\"/images/common/page_arrow_4.gif\" alt=\"다음\"></a>
	<a href=\"#\" class=\"arrow\"><img src=\"/images/common/page_arrow_3.gif\" alt=\"마지막페이지로\"></a>	
	*/

	// 사용자 페이징 처리.
	function PageList($pUrl) 
	{ 
		//$pPreImgN="<img src=\"/resources/img/page_arrow_1.gif\" alt=\"첫페이지로\">";
		//$pPreImg="<img src=\"/resources/img/page_arrow_2.gif\" alt=\"이전\">";
		//$pNextImg="<img src=\"/resources/img/page_arrow_3.gif\" alt=\"다음\">";
		//$pNextImgN="<img src=\"/resources/img/page_arrow_4.gif\" alt=\"마지막페이지로\">";

		echo "<a href='$pUrl&page=1' class=\"arrow first\">첫페이지로</a>\n";

		if($this->mStartPage>$this->mPageSet) { 
			$pImsiPage=$this->mStartPage-$this->mPageSet; 
			echo "<a href='".$pUrl."&page=$pImsiPage' class=\"arrow prev\">이전</a>\n"; 
		} 
		else echo "<a href=\"#\" class=\"arrow prev\">이전</a>\n"; 

		for($i=$this->mStartPage; $i<=$this->mEndPage; $i++){ 
			if($i==$this->mCurrPage) echo "<a href=\"#\" class=\"on\"><span>$i</span></a>\n"; 
			else echo "<a href='".$pUrl."&page=$i'><span>$i</span></a>\n"; 
			//  if($i < $this->mEndPage) echo "<li>|</li>\n";
		} 

		if($this->mEndPage<$this->mLastPage) { 
			$pImsiPage=$this->mStartPage+$this->mPageSet; 
			echo "<a href='".$pUrl."&page=$pImsiPage' class=\"arrow next\">다음</a>\n"; 
		} 
		else echo "<a href=\"#\" class=\"arrow next\">$pNextImg</a>\n"; 

		echo "<a href='$pUrl&page=$this->mLastPage' class=\"arrow last\">마지막페이지로</a>\n";
	}
	

	// 관리자 페이징 처리.
	function AdminPageList($pUrl) 
	{ 

		$html = "<div class=\"page-left\">";
		$html.=  "	<a href=\"$pUrl&page=1\" class=\"btn-first\"></a>";
		if($this->mStartPage>$this->mPageSet) { 
			$pImsiPage=$this->mStartPage-$this->mPageSet; 
			$html.=  "	<a href=\"$pUrl&page=$pImsiPage\" class=\"btn-prev\"></a>";  
		}
		else{
			$html.=  "";  
		}
		$html.=	"</div>";
		$html.=	"<div class=\"number\">";
		for($i=$this->mStartPage; $i<=$this->mEndPage; $i++){ 
			if($i==$this->mCurrPage) $html.=	"	<a href=\"$pUrl&page=$i\" class=\"on\">$i</a>";
			else $html.=	"	<a href=\"$pUrl&page=$i\">$i</a>";
		}
		$html.=	"</div>";
		$html.=	"<div class=\"page-right\">";
		if($this->mEndPage<$this->mLastPage) { 
			$pImsiPage=$this->mStartPage+$this->mPageSet; 
			$html.=  "	<a href=\"$pUrl&page=$pImsiPage\" class=\"btn-next\"></a>";
		} 
		else{
			$html.=  "";
		} 
		$html.=	"	<a href=\"$pUrl&page=$this->mLastPage\" class=\"btn-last\"></a>";
		$html.=	"</div>";

		echo $html;
	}
}
?>