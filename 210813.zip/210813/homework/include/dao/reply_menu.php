<?php
//class AdminMenuSql
class ReplyMenuSql
{
	var $seq;
	var $boardSeq ;
	var $isUse	;
	var $content;
	var $pw;
	var $regDate;
	var $regId;

	// 관리자메뉴 리스트
	function ReplyMenuList ($pConnect, $seq) 
	{	
		$Sql = "SELECT seq, board_seq, pw, content, is_use, reg_date, reg_id FROM reply WHERE seq=".$seq;

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["seq"]);
			$ResultValue[$i]->boardSeq = stripcslashes($Result["board_seq"]);
            $ResultValue[$i]->pw		= stripcslashes($Result["pw"]);
			$ResultValue[$i]->content	= stripcslashes($Result["content"]);
			$ResultValue[$i]->isUse		= stripcslashes($Result["is_use"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["reg_date"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["reg_id"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		//echo $Sql;
		return $LsResult;
	}

    // 게시글 리플 총 개수
    function ReplyCnt ($seq,$pConnect){
        $Sql = "SELECT COUNT(*) FROM reply where board_seq=$seq";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		$Result = @mysqli_fetch_row($Sql_que);
		$CountAll=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

    }

	// 관리자메뉴 추가
	function SelectMaxSeq ($pConnect) 
	{
		$Sql = "SELECT IFNULL(MAX(SEQ)+1, 1) AS MAX_SEQ FROM reply";
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		$Result = @mysqli_fetch_row($Sql_que);
		$maxSeq=$Result[0];
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		return $maxSeq;

	} // end function
    
    // 댓글 수정 불러오기
    function SelectWithSeq ($seq, $pConnect)
	{
		$Sql = "SELECT * FROM reply WHERE SEQ = $seq";
       // echo "<br>sql=".$Sql."<br>";
		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["SEQ"]);
			$ResultValue[$i]->boardId		= stripcslashes($Result["BOARD_ID"]);
			$ResultValue[$i]->content	= stripcslashes($Result["CONTENT"]);
			$ResultValue[$i]->pw	= stripcslashes($Result["PW"]);
			$ResultValue[$i]->regDate	= stripcslashes($Result["REG_DATE"]);
			$ResultValue[$i]->regId	= stripcslashes($Result["REG_ID"]);
			$ResultValue[$i]->isOpen	= stripcslashes($Result["IS_USE"]);
			$LsResult[$i] = $ResultValue[$i];
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

		return $LsResult;

	} // end function


    function Insert($maxSeq, $pConnect)
	{
		$Sql = "INSERT INTO reply (SEQ, BOARD_SEQ, PW, CONTENT, REG_DATE, REG_ID, REG_IP, IS_USE)";
		$Sql.= " VALUES (";
		$Sql.= $maxSeq;
		$Sql.= ", '".$this->seq;
        $Sql.= "', '".$this->pw;
		$Sql.= "','".$this->content;
		$Sql.= "',now()";
		$Sql.= ",'".$this->regId;
		$Sql.= "','".$this->regIp;
		$Sql.= "','".$this->isUse;
		$Sql.= "')";        
		$Sql_que = @mysqli_query($pConnect, $Sql)or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error());
		unset($Sql_que);
		//echo ($Sql);

    }
   

	// 리플 수정
	function ReplyMenuEdit ($seq, $pConnect) 
	{	
		// 선택된메뉴수정
		$Sql = "update reply set ";
		$Sql .= " content = '".$this->content."', ";
		$Sql .= "	is_use = '".$this->isUse."',  ";
		$Sql .= "	mod_date = now(),  ";
		$Sql .= "	reg_id = '".$this->regId."'  ";
		$Sql .= "	where seq = ".$this->seq;
			
		$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>". mysqli_error($pConnect));
		unset($result);
	}


	// 리플 삭제
	function ReplyDelete($seq, $pConnect) 
	{	
		// 현재메뉴의 하부메뉴.
		$Sql = "SELECT seq, board_seq, content FROM reply WHERE seq=".$seq;
		$result = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
		
		$Sql = "DELETE FROM reply WHERE seq = ".$seq;
		@mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error($pConnect));
			
		unset($result);

	}

	
	// 댓글 리스트 불러오기
	function replyLs ($seq, $pConnect ) 
	{	
        $Sql = "SELECT seq, content, reg_id, reg_date FROM reply WHERE board_seq=".$seq;

		$LsResult = array();
		$Sql_que = @mysqli_query($pConnect, $Sql) or die(mysqli_error($pConnect)); 
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq		= stripcslashes($Result["seq"]);
			$ResultValue[$i]->content = stripcslashes($Result["content"]);
			$ResultValue[$i]->regId		= stripcslashes($Result["reg_id"]);
            $ResultValue[$i]->regDate	= stripcslashes($Result["reg_date"]);
			$LsResult[$i] = $ResultValue[$i];
			//echo str_repeat(' ',$level).$row['menu_nm']. "[".$row['seq']."][".$row['parent_seq']."][".$row['sort']."]" ;
		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);

        $replyLs = new stdClass();
		$replyLs->mData = $LsResult;
		return $replyLs;
		
		
	}

    // sql/boardSQL.php 
    // class 선언 및 이전 코드는 생략합니다.
    // 리플 달기
    public function createReply ($param) {
        
        $rid = $this->getReplyId($param["reply"]);
        $hash = $this->hashPassword($param["passwd"]);

        $stmt = $this->connection->prepare("INSERT INTO `list`(subject, contents, passwd, name, rid, reply, depth, regdate) VALUES(:subject, :contents, :isPasswd, :name, :rid, :reply, :depth, :regdate)");
        $stmt->bindParam(":subject", $param["subject"], PDO::PARAM_STR);
        $stmt->bindParam(":contents", $param["contents"], PDO::PARAM_STR);
        $stmt->bindParam(":isPasswd", $hash["pw"], PDO::PARAM_STR);
        $stmt->bindParam(":name", $param["name"], PDO::PARAM_STR);
        $stmt->bindParam(":rid", $rid, PDO::PARAM_INT);
        $stmt->bindParam(":reply", $param["reply"], PDO::PARAM_INT);
        $stmt->bindParam(":depth", $param["depth"], PDO::PARAM_INT);
        $stmt->bindParam(":regdate", $param["regdate"], PDO::PARAM_STR);
        $result = $stmt->execute();

        if ($result) {
            return array("type" => 1, "rid" => $rid);
        } else {
            return array("type" => 0);
        }
    }

    // 리플 아이디 가져오기
    public function getReplyId ($reply) {
        $stmt = $this->connection->prepare("SELECT MAX(rid) as ids FROM `list` WHERE reply = :reply");
        $stmt->bindParam(":reply", $reply, PDO::PARAM_INT);
        $stmt->execute();
        $id = $stmt->fetch(PDO::FETCH_ASSOC)["ids"];

        return $id + 1;
    }

    // 마지막 아이디
    public function getLastKey () {
        return $this->connection->lastInsertId();
    }    

	

}
?>
