<?php
require_once("../../../include/common/conf.php");
require_once("../../../include/common/dbconn.php");
require_once("../../../include/common/function.php");
require_once("../../../include/common/pageout.php");
require_once("../../../include/dao/admin_user.php");
require_once("../../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../../include/common/page_authority.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));


$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?searchKey=$searchKey&searchValue=$searchValue";


$seq = $_SESSION[SS_ADM_SEQ];

if($seq=="") {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}

$gConn = new DBConn();
$AdminSql = new AdminSql();
$Result = $AdminSql->SelectWithSeq ( $seq, $gConn->mConn );

// 권한정보 불러오기.
$CodeListSql = new CodeListSql();
$CodeListSql->codeGroup='ADMIN_GROUP';
$GroupResult = $CodeListSql->SelectCodeGroupList ($gConn->mConn) ;

$gConn->DisConnect();

if(count($Result)==0) {
      echo "
      <Script>
              alert('정보가 없습니다.');
              history.back();
      </Script>
      ";
      exit;
}

?>

<?
//echo $Result[0]->admEmail . "<br />";
//echo strrpos($Result[0]->admEmail, "@") . "<br />";

if (strlen($Result[0]->admEmail) > 0){
	$email1 = substr($Result[0]->admEmail, 0, strrpos($Result[0]->admEmail, "@")) ; // 이메일 앞글자 찾기.
	$email2 = substr($Result[0]->admEmail, strrpos($Result[0]->admEmail, "@")+1, strlen($Result[0]->admEmail)) ; // 나머지 도메인 찾기.
}				
//echo $email1 . "<br />";
//echo $email2 . "<br />";

?>

<?include "../../common/topmenu.php"?>
	<script type="text/javascript">
	<!--

	function fn_submit() {
		
		var regEmail = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		var regPhone = /^((01[1|6|7|8|9])[1-9]+[0-9]{6,7})|(010[1-9][0-9]{7})$/;

		if ( $('#admId').val() == '' ) {
			alert('아이디를 입력해 주세요.');
			$('#admId').focus();
			return;
		}

		if ( $('#admPw').val() == '' ) {
			alert('현재비밀번호를 입력해 주세요.');
			$('#admPw').focus();
			return;
		}
		if(checkPwdVal($("#admPw").val()) == false){
			alert("영문/숫자/특수문자 8~15자 이상으로 비밀번호를 만들어 주세요."); $("#admPw").focus(); return;
		}


		if ( $('#admPwRe').val() != '' ) {
			if(checkPwdVal($("#admPwRe").val()) == false){
				alert("영문/숫자/특수문자 8~15자 이상으로 비밀번호를 만들어 주세요."); $("#admPwRe").focus(); return;
			}
			if ( $('#admPwReRe').val() == '' ) {
				alert('변경비밀번호 재입력를 입력해 주세요.');
				$('#admPwReRe').focus();
				return;
			}
			if(checkPwdVal($("#admPwReRe").val()) == false){
				alert("영문/숫자/특수문자 8~15자 이상으로 비밀번호를 만들어 주세요."); $("#admPwReRe").focus(); return;
			}
			if ( $('#admPwRe').val() != $('#admPwReRe').val()) {
				alert('변경비밀번호가 일치하지 않습니다.');
				$('#admPwReRe').focus();
				return;
			}
		}

		if ( $('#admNm').val() == '' ) {
			alert('성명을 입력해 주세요.');
			$('#admNm').focus();
			return;
		}

		/*
		if(regEmail.test($('#email1').val() + '@' + $('#email2').val()) == false ) {
			alert('이메일 주소가 유효하지 않습니다');
			$('#email2').focus();
			return;
		}
		if ( $('#tel').val() == '' ) {
			alert('연락처을 입력해 주세요.');
			$('#tel').focus();
			return;
		}
		*/
		//
		//		if ( $('#authGbn').val() == '' ) {
		//			alert('권한을 선택해 주세요.');
		//			$('#authGbn').focus();
		//			return;
		//		}

		/*
		if ( $('#isUse').val() == '' ) {
			alert('사용여부를 선택해 주세요.');
			$('#isUse').focus();
			return;
		}
		*/
		
		//alert("d");
		$('#frmWrite').attr("action","self_modify_exec.php");
		$('#frmWrite').submit();
		//document.frmWrite.submit();


	}
	function mail_copy(frm) {
		if (frm.email3.value=='D') // 직접입력이면.
		{
			f.email2.value = "";
		}
		else
		{
			frm.email2.value=frm.email3.value;
		}
	}		
	//-->
	</script>

	<form name="frmWrite" id="frmWrite" action="self_modify_exec.php" method="post">
	<input type="hidden" name="page" value="<?=$page?>">
	<input type="hidden" name="searchKey" value="<?=$searchKey?>">
	<input type="hidden" name="searchValue" value="<?=$searchValue?>">
	<input type="hidden" name="seq" value="<?=$seq?>">
	<input type="hidden" name="mode" value="self">
	<input type="hidden" name="authGbn" value="<?=$Result[0]->authGbn?>">
	<input type="hidden" name="isUse" value="<?=$Result[0]->isUse?>">
	<input type="hidden" name="admPw" value="<?=$Result[0]->admPw?>">
	<?
	// CSRF 취약점 대응.
	$token = md5(uniqid(rand(),true));
	$_SESSION['TOKEN'] = $token;	
	?>
	<input type="hidden" name="token" value="<?=$token?>">

	<div class="admincontbox">
	  <div class="admincont">
		<h3>사용자 수정</h3>

		<div class="admboard-rapper mt-20">
			<table width="100%" class="adm_boarview">
				<colgroup>
					<col width="20%" />
					<col width="" />
				</colgroup>
				<tbody>
				<tr>
					<th scope="row">아이디</th>
					<td>
						<input type="text" class="textform" style="width:15%;" name="admId" id="admId" value="<?=$Result[0]->admId?>" readonly/> <label>아이디는 수정 하실 수 없습니다.</label>
					</td>
				</tr>
				<tr>
					<th scope="row">현재비밀번호</th>
					<td>
						<input type="password" class="textform" style="width:17%;" name="admPw" id="admPw"/><label>영문/숫자/특수문자 8~15자 이상</label>
					</td>
				</tr>
				<tr>
					<th scope="row">변경비밀번호</th>
					<td>
						<input type="password" class="textform" style="width:17%;" name="admPwRe" id="admPwRe"/><label>영문/숫자/특수문자 8~15자 이상</label>
					</td>
				</tr>
				<tr>
					<th scope="row">변경비밀번호 재입력</th>
					<td>
						<input type="password" class="textform" style="width:17%;" name="admPwReRe" id="admPwReRe"/><label>영문/숫자/특수문자 8~15자 이상</label>
					</td>
				</tr>
				<tr>
					<th scope="row">성명</th>
					<td>
						<input type="text" class="textform" style="width:15%;" name="admNm" id="admNm" value="<?=$Result[0]->admNm?>"/>
					</td>
				</tr>


				<tr>
					<th scope="row">이메일</th>
					<td>
						<input type="text" class="textform" style="width:15%;" name="email1" id="email1" value="<?=$email1?>">@
						<input type="text" class="textform" style="width:20%;" name="email2" id="email2" value="<?=$email2?>">
						<select class="selbox" name="email3" id="email3" onChange="mail_copy(this.form)">
							<option value="" <?if ($email2=='') { echo 'selected';}?>>직접 입력</option>
							<option value="naver.com" <?if ($email2=='naver.com') { echo 'selected';}?>>naver.com</option>
							<option value="hanmail.net" <?if ($email2=='hanmail.net') { echo 'selected';}?>>hanmail.net</option>
							<option value="nate.com" <?if ($email2=='nate.com') { echo 'selected';}?>>nate.com</option>
							<option value="hotmail.com" <?if ($email2=='hotmail.com') { echo 'selected';}?>>hotmail.com</option>
							<option value="paran.com" <?if ($email2=='paran.com') { echo 'selected';}?>>paran.com</option>
							<option value="korea.com" <?if ($email2=='korea.com') { echo 'selected';}?>>korea.com</option>
							<option value="empal.com" <?if ($email2=='empal.com') { echo 'selected';}?>>empal.com</option>
							<option value="yahoo.co.kr" <?if ($email2=='yahoo.co.kr') { echo 'selected';}?>>yahoo.co.kr</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">연락처</th>
					<td>
						<input type="text" class="textform" style="width:20%;" name="tel" id="tel" value="<?=$Result[0]->tel?>"/>
					</td>
				</tr>
				
				<!--
				<tr>
					<th scope="row">관리자그룹</th>
					<td>
						<select class="type01" name="authGbn" id="authGbn">
						<option value="">==========</option>
						<?
						for($i=0; $i<count($GroupResult); $i++) {
						?>
							<option value="<?=$GroupResult[$i]->code?>" <?if ($GroupResult[$i]->code==$Result[0]->code) {echo " selected ";}?>><?=$GroupResult[$i]->codeNm?></option>
						<?}?>
					</td>
				</tr>
				<tr>
					<th scope="row">사용여부</th>
					<td>
						<select class="type01" name="isUse" id="isUse">
							<option value="Y" <?if ($Result[0]->isUse=='') { echo 'selected';}?>>사용</option>
							<option value="N" <?if ($Result[0]->isUse=='') { echo 'selected';}?>>중지</option>
						</select>						
					</td>
				</tr>
				-->

				</tbody>
			</table>
		</div>

		<div class="adm_board_btn">
			<a href="javascript:fn_submit();" class="admbtn_add">저장</a>
			<a href="javascript:document.frmWrite.reset();" class="admbtn_type03">취소</a>
		</div>

	  </div>
	</div>
	
	</form>

<?include "../../common/footer.php"?>