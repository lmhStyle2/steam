<?php
    require_once("../../include/dao/conf.php");
	require_once("../../include/dao/dbconn.php");
	require_once("../../include/dao/function.php");
	require_once("../../include/dao/admin_menu.php");
    require_once("../../include/dao/admin_user.php");
    require_once("../../include/dao/pageout.php");
    require_once("../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));

//$CommLink = "";

$pHtmlLink = "list.php";

if (!$page) $page=1;


$searchKey = $searchValue ? '3' : '';


$gConn = new DBConn();
$AdminSql = new AdminSql();
$PageLs = $AdminSql->PageLs ( $pWhere, $searchKey, $searchValue, $page, 10, $gConn->mConn );
$gConn->DisConnect();

$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?searchKey=$searchKey&searchValue=$searchValue";
?>


<?include "../../common/topmenu.php"?>

	<script type="text/javascript">
	<!--
	function fn_submit() {
		/*
		if ( $('#joinNm').val() == '' ) {
			alert('성명을 입력해 주세요.');
			$('#joinNm').focus();
			return;
		}
		*/
			
		//$('#frmList').attr("action",$('#sslUrl').val());
		//alert('성명을 입력해 주세요.');
		$('#frmList').submit();
	}	
	//-->
	</script>


	<form name="frmList" id="frmList" action="<?=$pHtmlLink?>" method="post">

	<div class="admincontbox">
	  <div class="admincont">
			<h3>관리자계정 목록</h3>
			<div class="topsearcharea">
					<input type="text" name="searchValue" id="searchValue" value="<?=$searchValue?>" onblur="if(this.value=='')this.value='';" onfocus="if(this.value=='');this.value='';"/>
					<input type="button" class="btn_search"  id="" onclick="fn_submit();"/>
			</div>

			<div class="total-count">
				<!--
				<select id="" class="selbox">
					<option value="" selected="selected">10개</option>
					<option value=""></option>
				</select>--> 총 <?=$PageLs->mListAll?>건
			</div>

			<div class="admboard-rapper">
				<table width="100%" class="adm_boardlist">
					<colgroup>
						<col width="8%" />
						<col width="20" />
						<col width="18%" />
						<col width="18%" />
						<col width="18%" />
						<col width="18%" />
					</colgroup>
					<thead>
					<tr>
						<th scope="col">NO</th>
						<th scope="col">아이디</th>
						<th scope="col">성명</th>
						<th scope="col">권한명</th>
						<th scope="col">등록자</th>
						<th scope="col">등록일자</th>
					</tr>
					</thead>
					<tbody>

					<?
					if(count($PageLs->mData)) {
						$pTotal = $PageLs->mListAll;
						
						for($i=0; $i<count($PageLs->mData); $i++) {
							$RowNo = $pTotal - $PageLs->mSizePage * ($page - 1);
					?>
							<tr>
								<td><?=$RowNo?></td>
								<td><a href="read.php<?=$CommLink?>&seq=<?=$PageLs->mData[$i]->seq?>&mode=read"><?=$PageLs->mData[$i]->admId?></a></td>
								<td><?=$PageLs->mData[$i]->admNm?></td>
								<td><?=$PageLs->mData[$i]->codeNm?></td>
								<td><?=$PageLs->mData[$i]->regId?></td>
								<td><?=$PageLs->mData[$i]->regDate?></td>
							</tr>
					<?
							$pTotal = $pTotal - 1;			//번호 desc
						}
					}
					else{
					?>
							<tr>
								<td colspan="6" align="center">조회된 데이타가 없습니다.</td>
							</tr>
					<?
					}
					?>
					
					</tbody>
				</table>
			</div>

			<div class="adm_board_btn">
				<a href="write.php<?=$CommLink?>&mode=write" class="admbtn_add">관리자등록</a>
                <a href="user_write.php<?=$CommLink?>&mode=write" class="admbtn_add">유저등록</a>
                <a href="user_list.php<?=$CommLink?>&mode=write" class="admbtn_add">유저리스트</a>
			</div>

			<div class="paging">
			<?
			if(count($PageLs->mData)) {
				$pUrl=$_SERVER["PHP_SELF"].$PageLink;
				$PageLs->AdminPageList($pUrl);
			}     
			?>					
			</div>

	  </div>
	</div>

	</form>

<?include "../../common/footer.php"?>