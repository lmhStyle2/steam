<?php
require_once("../../../include/common/conf.php");
require_once("../../../include/common/dbconn.php");
require_once("../../../include/common/function.php");
require_once("../../../include/common/pageout.php");
require_once("../../../include/dao/admin_user.php");
require_once("../../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../../include/common/page_authority.php");
?>
<?

if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));

$admNm = isset($_REQUEST['admNm']) ? $_REQUEST['admNm'] : '';
$email1 = isset($_REQUEST['email1']) ? $_REQUEST['email1'] : '';
$email2 = isset($_REQUEST['email2']) ? $_REQUEST['email2'] : '';
$tel = isset($_REQUEST['tel']) ? $_REQUEST['tel'] : '';
$authGbn = isset($_REQUEST['authGbn']) ? $_REQUEST['authGbn'] : '';
$isUse = isset($_REQUEST['isUse']) ? $_REQUEST['isUse'] : '';

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$mode = isset($_REQUEST['mode']) ? $_REQUEST['mode'] : '';

$admPw = isset($_REQUEST['admPw']) ? $_REQUEST['admPw'] : '';
$admPwRe = isset($_REQUEST['admPwRe']) ? $_REQUEST['admPwRe'] : '';
$admPwReRe = isset($_REQUEST['admPwReRe']) ? $_REQUEST['admPwReRe'] : '';

$admNm = sqlInject(rejectXss($admNm));
$email1 = sqlInject(rejectXss($email1));
$email2 = sqlInject(rejectXss($email2));
$tel = sqlInject(rejectXss($tel));
$authGbn = sqlInject(rejectXss($authGbn));
$isUse = sqlInject(rejectXss($isUse));

$seq = sqlInject(rejectXss($seq));
$mode = sqlInject(rejectXss($mode));


$admId =  $_SESSION[SS_ADM_ID] ;  

if ($email1!="") {
	if ($email2!="") {
		$admEmail = $email1. "@" . $email2;
	}
}

if ($seq==""||$admPw=="") {
      echo "
      <Script>
              alert('기본값이 없습니다.');
              history.back();
      </Script>
      ";
      exit;
}

//echo $content;
//exit;

$gConn = new DBConn();

// 디비 객체
$AdminSql = new AdminSql();

// 계정조회.
$AdminSql->admId=$admId;
$AdminSql->admPw=$admPw;
$existAdmin = $AdminSql->SelectAdminSelfModify($gConn->mConn ) ;

if (count($existAdmin) == 0){
	$gConn->DisConnect();
	
	echo "
		<Script>
		  alert('입력하신 계정정보가 올바르지 않거나 본인의 계정만 수정이 가능합니다.');
		  history.back();
		</Script>
		";
		exit;
}

if (!is_empty($admPwRe)){ // 변경비밀번호를 입력한 경우
	if ($admPwRe==$admPwReRe){
		$AdminSql->admPw=$admPwRe;  // 변경될 비밀번호
	}
	else{
		$gConn->DisConnect();
		echo "
			<Script>
			  alert('비밀번호가 올바르지 않습니다[2].');
			  history.back();
			</Script>
			";
			exit;
	}
}

//echo count($existAdmin);
//exit;

$AdminSql->seq=$seq;
$AdminSql->admNm=$admNm;
$AdminSql->admEmail=$admEmail;
$AdminSql->tel=$tel;
$AdminSql->regId=$_SESSION[SS_ADM_ID];

// 수정
$AdminSql->AdminSelfUpdate( $gConn->mConn ) ;

// 종료
$gConn->DisConnect();

$pHtmlLink="self_modify.php";
$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";

$pUrl=$pHtmlLink.$CommLink;

//echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";

alertMsgUrl("수정되었습니다.", "$pUrl");
?>