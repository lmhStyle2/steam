<?php
require_once("../../include/dao/conf.php");
require_once("../../include/dao/dbconn.php");
require_once("../../include/dao/function.php");
require_once("../../include/dao/pageout.php");
require_once("../../include/dao/admin_user.php");
require_once("../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?
$pWhere = "";
$pHtmlLink = "";

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));
$seq = sqlInject(rejectXss($seq));

if($seq=="") {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}

$gConn = new DBConn();
$AdminSql = new AdminSql();
$Result = $AdminSql->SelectWithSeq ( $seq, $gConn->mConn );
$gConn->DisConnect();

$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?searchKey=$searchKey&searchValue=$searchValue";
?>

<?include "../../common/topmenu.php"?>


<script type="text/javascript">
<!--
function deleteConfirm(){
	if (confirm("삭제하시겠습니까?")){
		$('#frmWrite').attr("action","delete_exec.php");
		$('#frmWrite').submit();
	}
	return;
}	
//-->
</script>

<form name="frmWrite" id="frmWrite" action="" method="post">
<input type="hidden" name="page" value="<?=$page?>">
<input type="hidden" name="searchKey" value="<?=$searchKey?>">
<input type="hidden" name="searchValue" value="<?=$searchValue?>">
<input type="hidden" name="seq" value="<?=$seq?>">
	<?
	// CSRF 취약점 대응.
	$token = md5(uniqid(rand(),true));
	$_SESSION['TOKEN'] = $token;	
	?>
	<input type="hidden" name="token" value="<?=$token?>">

	<div class="admincontbox">
	  <div class="admincont">
			<h3>사용자 상세보기</h3>

			<div class="admboard-rapper mt-20">
				<table width="100%" class="adm_boarview">
					<colgroup>
						<col width="20%" />
						<col width="" />
					</colgroup>
					<tbody>
					<tr>
						<th scope="row">아이디</th>
						<td><?=$Result[0]->admId?></td>
					</tr>
					<tr>
						<th scope="row">성명</th>
						<td><?=$Result[0]->admNm?></td>
					</tr>					
					<tr>
						<th scope="row">사용여부</th>
						<td><?=$Result[0]->isUse?></td>
					</tr>
					<tr>
						<th scope="row">등록자(등록일자)</th>
						<td>
							<?=$Result[0]->regId?> (<?=$Result[0]->regDate?>)
						</td>
					</tr>
					</tbody>
				</table>
			</div>

			<div class="adm_board_btn">
				<a href="modify.php<?=$CommLink?>&mode=modify&seq=<?=$seq?>" class="admbtn_add">수정</a>
				<a href="javascript:deleteConfirm();" class="admbtn_type04">삭제</a>
				<a href="list.php<?=$CommLink?>" class="admbtn_type03">목록</a>
			</div>

	  </div>
	</div>

</form>

<?include "../../common/footer.php"?>