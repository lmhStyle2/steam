<?php
require_once("../../include/dao/conf.php");
require_once("../../include/dao/dbconn.php");
require_once("../../include/dao/function.php");
require_once("../../include/dao/admin_menu.php");
require_once("../../include/dao/user.php");
require_once("../../include/dao/pageout.php");
require_once("../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?

if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}


$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$admId = isset($_REQUEST['admId']) ? $_REQUEST['admId'] : '';
$admPw = isset($_REQUEST['admPw']) ? $_REQUEST['admPw'] : '';
$admPwRe = isset($_REQUEST['admPwRe']) ? $_REQUEST['admPwRe'] : '';
$admNm = isset($_REQUEST['admNm']) ? $_REQUEST['admNm'] : '';
$email1 = isset($_REQUEST['email1']) ? $_REQUEST['email1'] : '';
$email2 = isset($_REQUEST['email2']) ? $_REQUEST['email2'] : '';
$tel = isset($_REQUEST['tel']) ? $_REQUEST['tel'] : '';
$authGbn = isset($_REQUEST['authGbn']) ? $_REQUEST['authGbn'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));
$admId = sqlInject(rejectXss($admId));
$admNm = sqlInject(rejectXss($admNm));
$email1 = sqlInject(rejectXss($email1));
$email2 = sqlInject(rejectXss($email2));
$tel = sqlInject(rejectXss($tel));
$authGbn = sqlInject(rejectXss($authGbn));


if ($email1!="") {
	if ($email2!="") {
		$admEmail = $email1. "@" . $email2;
	}
}

//echo $content;
//exit;

if($admId==""||$admPw=="") {
      echo "
      <Script>
		  alert('기본값이 없습니다.');
		  history.back();
      </Script>
      ";
      exit;
}

if($admPw!=$admPwRe) {
      echo "
      <Script>
		  alert('비밀번호값이 서로 다릅니다.');
		  history.back();
      </Script>
      ";
      exit;
}

/*
if(!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
	echo "<meta http-equiv='refresh' content='0;url=login.php'>";
	exit;
}
*/

$gConn = new DBConn();

// 디비 객체
$AdminSql = new AdminSql();

// 중복 조회.
$existAdmin = $AdminSql->SelectDup($userId, $gConn->mConn ) ;

if ($existAdmin[0] > 0){
	$gConn->DisConnect();
	echo "
      <Script>
		  alert('이미존재하는 계정입니다.');
		  history.back();
      </Script>
      ";
      exit;
}

// 기본키 구하기.
$maxSeq = $AdminSql->SelectMaxSeq( $gConn->mConn ) ;

$AdminSql->seq=$maxSeq;
$AdminSql->admId=$admId;
$AdminSql->admPw=$admPw;
$AdminSql->admNm=$admNm;
$AdminSql->admEmail=$admEmail;
$AdminSql->tel=$tel;
$AdminSql->authGbn=$authGbn;
$AdminSql->regId=$_SESSION[SS_ADM_ID];
$AdminSql->isUse=$isUse;

// 저장
$AdminSql->AdminInsert( $gConn->mConn ) ;

// 종료
$gConn->DisConnect();

$pHtmlLink="list.php";
$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$pUrl=$pHtmlLink.$CommLink;

//echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";

alertMsgUrl("저장되었습니다.", "$pUrl");
?>
