<?php
    require_once("../../include/dao/conf.php");
	require_once("../../include/dao/dbconn.php");
	require_once("../../include/dao/function.php");
	require_once("../../include/dao/admin_menu.php");
    require_once("../../include/dao/user.php");
    require_once("../../include/dao/pageout.php");
    require_once("../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));


$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";

// 권한정보 불러오기.
$gConn = new DBConn();

$CodeListSql = new CodeListSql();
$CodeListSql->codeGroup='ADMIN_GROUP';
$Result = $CodeListSql->SelectCodeGroupList ($gConn->mConn) ;
$gConn->DisConnect();

/*
if (count($Result)==0) {
	echo "
	<Script>
			  alert('조회내용이 없습니다.');
			  history.back();
	</Script>
	";
	exit;
}
*/
?>

<?include "../../common/topmenu.php"?>
	<script type="text/javascript">
	<!--

	function fn_submit() {
		
		var regEmail = /([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		var regPhone = /^((01[1|6|7|8|9])[1-9]+[0-9]{6,7})|(010[1-9][0-9]{7})$/;

		if ( $('#admId').val() == '' ) {
			alert('아이디를 입력해 주세요.');
			$('#admId').focus();
			return;
		}
		
		if ( $('#admPw').val() == '' ) {
			alert('비밀번호를 입력해 주세요.');
			$('#admPw').focus();
			return;
		}
		if(checkPwdVal($("#admPw").val()) == false){
			alert("영문/숫자/특수문자 8~15자 이상으로 비밀번호를 만들어 주세요."); $("#admPw").focus(); return;
		}

		if ( $('#admPwRe').val() == '' ) {
			alert('비밀번호 확인를 입력해 주세요.');
			$('#admPwRe').focus();
			return;
		}
		if(checkPwdVal($("#admPwRe").val()) == false){
			alert("영문/숫자/특수문자 8~13자 이상으로 비밀번호를 만들어 주세요."); $("#admPwRe").focus(); return;
		}

		if ( $('#admPw').val() != $('#admPwRe').val()) {
			alert('비밀번호가 서로 일치하지 않습니다.');
			$('#admPwRe').focus();
			return;
		}

		if ( $('#authGbn').val() == '' ) {
			alert('권한을 선택해 주세요.');
			$('#authGbn').focus();
			return;
		}
		/*
		if ( $('#isUse').val() == '' ) {
			alert('사용여부를 선택해 주세요.');
			$('#isUse').focus();
			return;
		}
		*/
		
		//alert("d");
		$('#frmWrite').attr("action","user_write_exec.php");
		$('#frmWrite').submit();
		//document.frmWrite.submit();


	}
	
	//-->
	</script>

	<form name="frmWrite" id="frmWrite" action="user_write_exec.php" method="post">
	<input type="hidden" name="boardId" value="<?=$boardId?>">
	<input type="hidden" name="page" value="<?=$page?>">
	<input type="hidden" name="searchKey" value="<?=$searchKey?>">
	<input type="hidden" name="searchValue" value="<?=$searchValue?>">
	<?
	// CSRF 취약점 대응.
	$token = md5(uniqid(rand(),true));
	$_SESSION['TOKEN'] = $token;	
	?>
	<input type="hidden" name="token" value="<?=$token?>">

	<div class="admincontbox">
	  <div class="admincont">
		<h3>관리자계정 등록</h3>

		<div class="admboard-rapper mt-20">
			<table width="100%" class="adm_boarview">
				<colgroup>
					<col width="20%" />
					<col width="" />
				</colgroup>
				<tbody>
				<tr>
					<th scope="row">아이디</th>
					<td>
						<input type="text" class="textform" style="width:15%;" name="admId" id="admId" />
					</td>
				</tr>
				<tr>
					<th scope="row">비밀번호</th>
					<td>
						<input type="password" class="textform" style="width:17%;" name="admPw" id="admPw" /><label>영문/숫자/특수문자 8~15자 이상</label>
					</td>
				</tr>
				<tr>
					<th scope="row">비밀번호확인</th>
					<td>
						<input type="password" class="textform" style="width:17%;" name="admPwRe" id="admPwRe" />
					</td>
				</tr>
				<tr>
					<th scope="row">성명</th>
					<td>
						<input type="text" class="textform" style="width:15%;" name="admNm" id="admNm" />
					</td>
				</tr>								
				<tr>
					<th scope="row">사용여부</th>
					<td>
						<select class="type01" name="isUse" id="isUse">
							<option value="Y">사용</option>
							<option value="N">중지</option>
						</select>						
					</td>
				</tr>
				</tbody>
			</table>
		</div>

		<div class="adm_board_btn">
			<a href="javascript:fn_submit();" class="admbtn_add">저장</a>
			<a href="list.php" class="admbtn_type03">목록</a>
		</div>

	  </div>
	</div>
	
	</form>

<?include "../../common/footer.php"?>