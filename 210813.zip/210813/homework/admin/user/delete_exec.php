<?php
require_once("../../../include/common/conf.php");
require_once("../../../include/common/dbconn.php");
require_once("../../../include/common/function.php");
require_once("../../../include/common/pageout.php");
require_once("../../../include/dao/admin_user.php");
require_once("../../../include/dao/code_list.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../../include/common/page_authority.php");
?>
<?

if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

$page = sqlInject(rejectXss($page));
$searchKey = sqlInject(rejectXss($searchKey));
$searchValue = sqlInject(rejectXss($searchValue));
$seq = sqlInject(rejectXss($seq));

//echo $content;
//exit;

if (is_empty($seq)) {
	  echo "
	  <Script>
			  alert('기본값이 없습니다.');
			  history.back();
	  </Script>
	  ";
	  exit;
}

// 디비 객체
$gConn = new DBConn();

$AdminSql = new AdminSql();

$AdminSql->AdminDelete($seq, $gConn->mConn ) ;

$gConn->DisConnect();

$pHtmlLink="list.php";
$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$pUrl=$pHtmlLink.$CommLink;

//echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";

alertMsgUrl("삭제되었습니다.", "$pUrl");
?>