<?php
require_once("../../include/dao/conf.php");
require_once("../../include/dao/dbconn.php");
require_once("../../include/dao/function.php");
require_once("../../include/dao/admin_menu.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?

//echo $_SESSION['TOKEN'] . '</br>';
//echo $_POST['token'] . '</br>';
/*
if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}
*/
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$parentSeq = isset($_REQUEST['parent_Seq']) ? $_REQUEST['parent_Seq'] : '';
$sortNum = isset($_REQUEST['sortNum']) ? $_REQUEST['sortNum'] : '';
$upDown = isset($_REQUEST['upDown']) ? $_REQUEST['upDown'] : '';

$seq = sqlInject(rejectXss($seq));
$parentSeq = sqlInject(rejectXss($parentSeq));
$sortNum = sqlInject(rejectXss($sortNum));
$upDown = sqlInject(rejectXss($upDown));

/*
echo  $seq . "<br>";
echo  $parentSeq . "<br>";
echo  $sortNum . "<br>";
echo  $upDown . "<br>";
exit;
*/
/*
if(is_empty($seq)||is_empty($board_id)||is_empty($sortNum)||is_empty($upDown)) {
		echo "
		<Script>
				  alert('기본값이 없습니다.');
				  history.back();
		</Script>
		";
		exit;
}
*/
$gConn = new DBConn();

// 디비 객체
$AdminMenuSql = new AdminMenuSql();

$AdminMenuSql->AdminMenuSort ($gConn->mConn, $seq, $parentSeq, $sortNum, $upDown);

$gConn->DisConnect();

echo"<meta http-equiv=\"refresh\" content=\"0; url=admin_menu_list.php\">";

?>