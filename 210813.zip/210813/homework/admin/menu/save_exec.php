<?php
require_once("../../include/dao/conf.php");
require_once("../../include/dao/dbconn.php");
require_once("../../include/dao/function.php");
require_once("../../include/dao/admin_menu.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<?
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$parentSeq = isset($_REQUEST['parentSeq']) ? $_REQUEST['parentSeq'] : '';
$sortNum = isset($_REQUEST['sortNum']) ? $_REQUEST['sortNum'] : '';
$mode = isset($_REQUEST['mode']) ? $_REQUEST['mode'] : '';

// 신규메뉴추가가 아니면 .

if ($rdoKind!='4'){
	if(is_empty($seq)||is_empty($parentSeq)||is_empty($sortNum)||is_empty($mode)) {
			echo "
			<Script>
					  alert('기본값이 없습니다.');
					  window.close();
			</Script>
			";
			exit;
	}
}

$rdoKind = isset($_REQUEST['rdoKind']) ? $_REQUEST['rdoKind'] : '';
$menuNm = isset($_REQUEST['menuNm']) ? $_REQUEST['menuNm'] : '';
$lowMenuNm = isset($_REQUEST['lowMenuNm']) ? $_REQUEST['lowMenuNm'] : '';
$menuUrl = isset($_REQUEST['menuUrl']) ? $_REQUEST['menuUrl'] : '';
$isUse = isset($_REQUEST['isUse']) ? $_REQUEST['isUse'] : '';
$sortNum = isset($_REQUEST['sortNum']) ? $_REQUEST['sortNum'] : '';

$seq = sqlInject(rejectXss($seq));
$parentSeq = sqlInject(rejectXss($parentSeq));
$sortNum = sqlInject(rejectXss($sortNum));
$mode = sqlInject(rejectXss($mode));
$rdoKind = sqlInject(rejectXss($rdoKind));
$menuNm = sqlInject(rejectXss($menuNm));
$lowMenuNm = sqlInject(rejectXss($lowMenuNm));
//$menuUrl = sqlInject(rejectXss($menuUrl));
$isUse = sqlInject(rejectXss($isUse));
$parentSeq = sqlInject(rejectXss($parentSeq));


//echo $_SESSION['TOKEN'] . '</br>';
//echo $_POST['token'] . '</br>';
if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}



$gConn = new DBConn();

// 디비 객체
$AdminMenuSql = new AdminMenuSql();

$AdminMenuSql->seq=$seq;
$AdminMenuSql->menuUrl=$menuUrl;
$AdminMenuSql->isUse=$isUse;
$AdminMenuSql->regId=$_SESSION[SS_ADM_ID];
$AdminMenuSql->sortNum=$sortNum;

//echo $rdoKind;

switch ($rdoKind) {
	case '1' : 
			$AdminMenuSql->menuNm=$menuNm;
			$Result = $AdminMenuSql->AdminMenuEdit ($gConn->mConn) ;		// 현재메뉴수정.
			$msg = '수정되었습니다.';
         break;
	case '2' : 
			$AdminMenuSql->menuNm=$lowMenuNm;
			$Result = $AdminMenuSql->AdminMenuAdd ($gConn->mConn) ;		// 하위메뉴추가.
			$msg = '등록되었습니다.';
         break;
	case '3' : 
			$Result = $AdminMenuSql->AdminMenuDel ($gConn->mConn, $seq) ;		// 현재메뉴삭제.
			$msg = '삭제되었습니다.';
         break;
	case '4' : 
			$AdminMenuSql->menuNm=$menuNm;
			$Result = $AdminMenuSql->AdminMenuAdd ($gConn->mConn, $seq) ;		// 신규메뉴추가.
			$msg = '등록되었습니다.';
         break;
	default : 
		print "error";
      break;
}

$gConn->DisConnect();

echo "<script language='javascript'>"; 
echo "alert('".$msg."');"; 
echo "window.opener.location.reload();"; 
echo "self.close();"; 
echo "</script>";
exit;

?>