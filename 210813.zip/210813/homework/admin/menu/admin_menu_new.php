<?php
	require_once("../../include/dao/conf.php");
	require_once("../../include/dao/dbconn.php");
	require_once("../../include/dao/function.php");
	require_once("../../include/dao/admin_menu.php");
	
?>
<?php
$seq = '0'; 

// 현재 선택한 메뉴명

$gConn = new DBConn();

$AdminMenuSql = new AdminMenuSql();

$Result = $AdminMenuSql->SelectWithSeq ($gConn->mConn, $seq) ;

$gConn->DisConnect();


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>site</title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link rel="stylesheet" href="../../css/admin.css" />
	<link rel="stylesheet" href="../../css/default.css" />
	<script src="../../js/datepicker-ko-KR.js" type="text/javascript"></script>
	<script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="../../js/jquery-ui.js" type="text/javascript"></script>
	<script src="../../js/common.js"></script>
	<script src="../../js/menu.js"></script>

	<script type="text/javascript">
	<!--
	$(document).ready(function(){
		$("#rdoKind0").click(function(){
			
		});
		$("#rdoKind1").click(function(){

		});
	});
	/*
	$(function(){
		 $("#check_all").click(function(){
			  var chk = $(this).is(":checked");//.attr('checked');
			  if(chk) $(".select_subject input").prop('checked', true);
			  else  $(".select_subject input").prop('checked', false);
		 });
	});
	*/
	// 저장.
	function formCheck(thisForm){
		
		if ( !$('input:radio[name="rdoKind"]:checked').val() ) {
			alert('구분을 선택해 주세요.');
			return;
		}
		if ( $('#menuNm').val() == '' ) {
			alert('메뉴명을 입력해 주세요.');
			$('#menuNm').focus();
			return;
		}
		if ( $('#menuUrl').val() == '' ) {
			alert('메뉴주소를 입력해 주세요.');
			$('#menuUrl').focus();
			return;
		}		

		//$('#frmWrite').attr("action",$('#sslUrl').val());
		$('#frmWrite').submit();
	}

	// 초기화.
	function formReset(thisForm){
		$('form').each(function(){
			this.reset();
		});
	}
	// 창닫기.
	function formClose(thisForm){
		window.close();
	}

	//-->
	</script>

</head>
<body>

<form name="frmWrite" id="frmWrite" action="save_exec.php" method="post">
<input type="hidden" name="seq" id="seq" value="<?=$seq?>">
<input type="hidden" name="parent_seq" id="parent_seq" value="<?=$parent_Seq?>">
<input type="hidden" name="sortNum" id="sortNum" value="<?=$sortNum?>">
<input type="hidden" name="mode" id="mode" value="<?=$mode?>">
<?
// CSRF 취약점 대응.
$token = md5(uniqid(rand(),true));
$_SESSION['TOKEN'] = $token;	
?>
<input type="hidden" name="token" value="<?=$token?>">

<div class="admincontbox pop">
  <div class="admincont pop">
		<h3> 등록</h3>
		<div class="admboard-rapper mt-20">
			<table width="100%" class="adm_boarview">
				<colgroup>
					<col width="20%" />
					<col width="" />
				</colgroup>
				<tbody>
				<tr>
					<th scope="row">구분</th>
					<td>
						<input type="radio" id="rdoKind0" name="rdoKind" value="4" checked/> <label for="rdoKind0">신규메뉴추가</lable>
					</td>
				</tr>
				<tr>
					<th scope="row">메뉴명</th>
					<td>
						<input type="text" class="textform" style="width:40%;" id="menuNm" name="menuNm" value="<?=$Result[0]->menuNm;?>"/>
					</td>
				</tr>
				<tr>
					<th scope="row">메뉴URL</th>
					<td>
						<input type="text" class="textform" style="width:77%;" id="menuUrl" name="menuUrl" value="<?=$Result[0]->menuUrl;?>"/>
					</td>
				</tr>
				<tr>
					<th scope="row">사용여부</th>
					<td>
						<select id="isUse" name="isUse" class="selbox">
							<option value="Y" <?if ($Result[0]->menuUrl == 'Y' || $Result[0]->menuUrl == '') { echo 'selected="selected"'; }?> >오픈</option>
							<option value="N" <?if ($Result[0]->menuUrl == 'N') { echo 'selected="selected"'; }?>>닫음</option>
						</select>							
					</td>
				</tr>
				</tbody>
			</table>
		</div>

		<div class="adm_board_btn">
			<a href="javascript:" onclick="formCheck(this);" class="admbtn_add">저장</a>
			<a href="javascript:" onclick="formReset(this);" class="admbtn_type02">초기화</a>
			<a href="javascript:" onclick="formClose(this);" class="admbtn_type03">닫기</a>
		</div>

  </div>
</div>

</form>

</body>
</html>