<?php
	require_once("../../include/dao/conf.php");
	require_once("../../include/dao/dbconn.php");
	require_once("../../include/dao/function.php");
	require_once("../../include/dao/admin_menu.php");
	
// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../../include/dao/page_authority.php");
?>
<link rel="stylesheet" href="../../css/admin.css" />
<link rel="stylesheet" href="../../css/default.css" />

<script src="../../js/jquery-1.9.1.min.js" type="text/javascript"></script>
<script src="../../js/jquery-ui.js" type="text/javascript"></script>

<script src="../../js/common.js"></script>
<script src="../../js/menu.js"></script>
<?include "../../common/topmenu.php"?>


	<script type="text/javascript">
	<!--
		function fn_edit(seq, parent_seq, sort_num, mode){
			var popup = window.open("admin_menu_edit.php?seq="+seq+"&parent_Seq="+parent_seq+"&sortNum="+sort_num+"&mode="+mode, 'fn_edit', 'width=700, height=500, scrollbar=yes, menubar=no');
			//popup.open();
		}
		function fn_add(){
			window.open("admin_menu_new.php?", "fn_add", "width=700, height=500, scrollbar=yes, menubar=no");
			//popup.open();
		}
		function fn_sort(seq, parent_Seq, sortNum, upDown){
			$('#seq').val(seq);
			$('#parent_Seq').val(parent_Seq);
			$('#sortNum').val(sortNum);
			$('#upDown').val(upDown);
			$('#frmList').attr("action","admin_menu_sort.php");
			$('#frmList').submit();
		}


	//-->
	</script>

	<form name="frmList" id="frmList" action="" method="post">
	<input type="hidden" name="seq" id="seq">
	<input type="hidden" name="parent_Seq" id="parent_Seq">
	<input type="hidden" name="sortNum" id="sortNum">
	<input type="hidden" name="upDown" id="upDown">
	<?
	// CSRF 취약점 대응.
	$token = md5(uniqid(rand(),true));
	$_SESSION['TOKEN'] = $token;	
	?>
	<input type="hidden" name="token" value="<?=$token?>">        
    
    
	<div class="admincontbox">
	    <div class="admincont">
			<h3>관리자메뉴 목록</h3>
			<br/>
			<div class="admboard-rapper">
				<table width="100%" class="adm_boardlist">
					<colgroup>
						<col width="" />
						<col width="" />
						<col width="" />
						<col width="" />
						<col width="" />
						<col width="" />
						<col width="" />
					</colgroup>
					<thead>
					<tr>
						<th scope="col">No</th>
						<th scope="col">메뉴명</th>
						<th scope="col">메뉴URL</th>
						<th scope="col">사용여부</th>
						<th scope="col">정렬순서</th>
						<th scope="col">관리</th>
						<th scope="col">정렬순서변경</th>
					</tr>
					</thead>
					<tbody>
						<?

						$gConn = new DBConn();
						$Sql = "SELECT count(1) FROM admin_menu ;";
						$Sql_que = @mysqli_query($gConn->mConn, $Sql)  or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()) ;
						$result = @mysqli_fetch_row($Sql_que);
						$totalCount = $result[0];
						@mysqli_free_result($Sql_que);
						unset($Sql_que);
						$gConn->DisConnect();
						
						function display_all($seq, $level) {
							
							global $totalCount; 

							$gConn = new DBConn();
							$Sql = "SELECT seq, parent_seq, menu_nm, menu_url, is_use, reg_date, reg_id, sort_num FROM admin_menu WHERE parent_seq=".$seq." order by sort_num asc;";
							$result = @mysqli_query($gConn->mConn, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()) ;                            
							$gConn->DisConnect();
							

							while ($row = @mysqli_fetch_array($result)) {
								if ($row['parent_seq']==0){
									echo '<tr bgcolor=#E7E9EF>';
								}
								else{
									echo '<tr>';
								}
								echo '<td>';
									echo $totalCount-- ;
								echo '</td>';
								echo "<td class='menu-name'>";
									// . "[".$row['seq']."][".$row['parent_seq']."][".$row['sort_num']."]"
									echo str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',$level).$row['menu_nm'];
								echo '</td>';
								echo '<td>';
									echo "<a href='/homework/".$row['menu_url']."'>".$row['menu_url']."</a>";
								echo '</td>';
								echo '<td>';
									echo $row['is_use'] ;
								echo '</td>';
								echo '<td>';
									echo $row['sort_num'] ;
								echo '</td>';
								echo '<td>';
								?>
									<input type="button" name="btnAdd" value="관리" onclick="fn_edit(<?=$row['seq']?>, <?=$row['parent_seq']?>, <?=$row['sort_num']?>, 'edit');">
								<?
								echo '</td>';
								echo '<td>';
								?>
									<input type="button" name="btnAdd" value="▲" onclick="fn_sort(<?=$row['seq']?>, <?=$row['parent_seq']?>, <?=$row['sort_num']?>, 'up');">
									<input type="button" name="btnAdd" value="▼" onclick="fn_sort(<?=$row['seq']?>, <?=$row['parent_seq']?>, <?=$row['sort_num']?>, 'down');">
								<?
								echo '</td>';
								echo '<tr>';
								//$totalCount = $totalCount - 1;
								display_all($row['seq'], $level+1);
							}
						}

						display_all(0, 0);

						
						?>
					
					</tbody>
				</table>
			</div>

			<div class="adm_board_btn">
				<a href="javascript:" onclick="fn_add();" class="admbtn_add">신규메뉴추가</a>
                <a href="../read.php" class="admbtn_add">게시판</a>
                <a href="../user/list.php" class="admbtn_add">관리자리스트</a>
			</div>

	    </div>
	</div>

	</form>

	<br/>
	<br/>
	<br/>
    <?include "../../common/footer.php"?>

