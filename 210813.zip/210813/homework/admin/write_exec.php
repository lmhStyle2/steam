<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['boardId']) ? $_REQUEST['boardId'] : '';

$isTop = isset($_REQUEST['isTop']) ? $_REQUEST['isTop'] : 'N';
$prDate = isset($_REQUEST['prDate']) ? $_REQUEST['prDate'] : '';
$prUrl = isset($_REQUEST['prUrl']) ? $_REQUEST['prUrl'] : '';
$prCom = isset($_REQUEST['prCom']) ? $_REQUEST['prCom'] : '';
$isOpen = isset($_REQUEST['isOpen']) ? $_REQUEST['isOpen'] : '';
$content = isset($_REQUEST['ir1']) ? $_REQUEST['ir1'] : '';

//echo $isTop;
//exit;

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";

$CommLink="?boardId=$boardId";

if (is_empty($boardId)) {
      echo "
      <Script>
              alert('기본값이 없습니다.');
              history.back();
      </Script>
      ";
      exit;
}

if($isTop=="") {
	$isTop = "N";
}



// 디비 객체
$gBoard = new BoardSql();

$gBoard->boardId=$boardId;
$gBoard->subject=scriptHtml($subject);
$gBoard->content=$content;
$gBoard->readCnt="0";
$gBoard->isTop=$isTop;
$gBoard->regId=$_SESSION[SS_ADM_ID];
$gBoard->regIp=$_SESSION[SS_ADM_IP];
$gBoard->prDate=$prDate;
$gBoard->prUrl=$prUrl;
$gBoard->prCom=$prCom;
$gBoard->isOpen=$isOpen;


//****************************************************
// 게시판 저장 시작
//****************************************************
$gConn = new DBConn();
$maxSeq = $gBoard->SelectMaxSeq( $gConn->mConn ) ;
$gBoard->Insert($maxSeq, $gConn->mConn ) ;

//****************************************************
// 게시판 저장 종료
//****************************************************


$result_file = array();

//****************************************************
// 이미지파일 업로드 시작.
//****************************************************
for ($i=0; $i<count($_FILES["upfile1"]["name"]); $i++) 
{
	if (is_uploaded_file($_FILES["upfile1"]["tmp_name"][$i]))  
	{
		$result_file=imgUp($_FILES["upfile1"]["tmp_name"][$i], $_FILES["upfile1"]["name"][$i], UPLOAD_DIR."/board/". $boardId. "/");
		/*	
		echo ($result_file[0]);	echo ("<br />");
		echo ($result_file[1]);	echo ("<br />");
		echo ($result_file[2]);	echo ("<br />");
		echo ($result_file[3]);	echo ("<br />");
		*/
		$gBoard->pSeq=$maxSeq;
		$gBoard->attGbn="I";
		$gBoard->fileOrgNm=$result_file[0];
		$gBoard->fileSvcNm=$result_file[1];
		$gBoard->thumbNm=$result_file[2];
		$gBoard->fSize=$result_file[2];

		$gBoard->FileInsert( $gConn->mConn ) ;
	}
}
//****************************************************
// 이미지파일 업로드 끝.
//****************************************************

//****************************************************
// 첨부파일 업로드 시작.
//****************************************************
for ($i=0; $i<count($_FILES["upfile2"]["name"]); $i++) 
{
	if (is_uploaded_file($_FILES["upfile2"]["tmp_name"][$i]))  
	{
		$result_file=fileUp($_FILES["upfile2"]["tmp_name"][$i], $_FILES["upfile2"]["name"][$i], $MAX_UPLOAD_SIZE, UPLOAD_DIR."/board/". $boardId. "/");
		/*	
		echo ($result_file[0]);	echo ("<br />");
		echo ($result_file[1]);	echo ("<br />");
		echo ($result_file[2]);	echo ("<br />");
		echo ($result_file[3]);	echo ("<br />");
		*/
		$gBoard->pSeq=$maxSeq;
		$gBoard->attGbn="F";
		$gBoard->fileOrgNm=$result_file[0];
		$gBoard->fileSvcNm=$result_file[1];
		$gBoard->thumbNm=$result_file[2];
		$gBoard->fSize=$result_file[2];

		$gBoard->FileInsert( $gConn->mConn ) ;
	}
}
//****************************************************
// 첨부파일 업로드 끝.
//****************************************************


$gConn->DisConnect();



$pHtmlLink="read.php";
$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$pUrl=$pHtmlLink.$CommLink;

echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";
?>
