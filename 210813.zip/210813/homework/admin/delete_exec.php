<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['boardId']) ? $_REQUEST['boardId'] : '';

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

if(is_empty($boardId)||is_empty($seq)) {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}

// 디비 객체
$gBoard = new BoardSql();
$gConn = new DBConn();

$result_file = array();
$upload = array();

//****************************************************
// 파일 삭제.
//****************************************************
//$ResultI = BoardSql::FileList ($seq, $boardId, 'I', $gConn->mConn) ; // 이미지 정보 조회.
//$ResultF = BoardSql::FileList ($seq, $boardId, 'F', $gConn->mConn) ; //  파일정보 조회.
/* 2021.08.10 현재 파일등록,수정,삭제부분은 스테이중
if(count($ResultI->mData)) {
	for($i=0; $i<count($ResultI->mData); $i++) {
		@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultI->mData[$i]->fileSvcNm);
		@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultI->mData[$i]->thumbNm);		
		$gBoard->FileDelete($ResultI->mData[$i]->seq, $gConn->mConn); // 디비 삭제	
	}
}

if(count($ResultF->mData)) {
	for($i=0; $i<count($ResultF->mData); $i++) {
		@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultF->mData[$i]->fileSvcNm);
		@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultF->mData[$i]->thumbNm);	
		$gBoard->FileDelete($ResultF->mData[$i]->seq, $gConn->mConn); // 디비 삭제	
	}
}
*/
$gBoard->BoardDelete($seq, $gConn->mConn ) ;

$gConn->DisConnect();

$pHtmlLink="read.php";
$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$pUrl=$pHtmlLink.$CommLink;

//echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";

alertMsgUrl("삭제되었습니다.", "$pUrl");
?>