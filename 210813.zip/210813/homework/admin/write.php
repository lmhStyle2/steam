<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";
$boardId = "notice";
if(is_empty($boardId)) {
    echo "
    <Script>
            alert('기본값이 없습니다.');
            history.back();
    </Script>
    ";
    exit;
}

?>

<? include "../common/topmenu.php" ?>

<link rel="stylesheet" href="//code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" type="text/css" />
<script src="../js/datepicker-ko-KR.js" type="text/javascript"></script>
<script language="javascript">
<!--


function formReset(obj){
	$('#insertBoardFrm')[0].reset();
}
//-->
</script>

	<? $boardId = "notice";?>
	<form action="write_exec.php" name="frm" id="insertBoardFrm" method="POST" enctype="MULTIPART/FORM-DATA">
	<!--<form name="frmWrite" id="frmWrite" action="write_exec.php" method="post" enctype="MULTIPART/FORM-DATA">-->
    <input type="hidden" name="boardId" value="<?=$boardId?>">
	<input type="hidden" name="page" value="<?=$page?>">
	<input type="hidden" name="searchKey" value="<?=$searchKey?>">
	<input type="hidden" name="searchValue" value="<?=$searchValue?>">
	<input type="hidden" name="seq" value="<?=$seq?>">

	<div class="admincontbox">
	  <div class="admincont">
			<h3><?=$pageTitle?> 등록</h3>
            

			<div class="admboard-rapper mt-20">
				<table width="100%" class="adm_boarview">
					<colgroup>
						<col width="20%" />
						<col width="" />
					</colgroup>
					<tbody>
                        <tr>
                            <th scope="row">제목</th>
                            <td>
                                <input type="text" class="textform" style="width:77%;" id="subject" name="subject"/>						
                                <input type="checkbox" name="isTop" id="isTop" class="checkbox-style1" value="Y"><label for="isTop"></label>중요
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">내용</th>
                            <td>	
                                <textarea name="ir1" id="ir1" rows="10" cols="100" style="width:100%; height:500px; display:none;"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">공지일</th>
                            <td>
                                <input type="text" class="textform" style="width:10%;" name="prDate" id="prDate" value="<?=date("Y-m-d")?>"/>
                            </td>
                        </tr>
                        <script>
                        $(function() {
                        $( "#prDate" ).datepicker();
                        });
                        </script>
                        <tr>
                            <th scope="row">게시여부</th>
                            <td>
                                <select id="isOpen" name="isOpen" class="selbox">
                                    <option value="Y" selected="selected">오픈</option>
                                    <option value="N">닫음</option>
                                </select>							
                            </td>
                        </tr>
					</tbody>
				</table>
			</div>

			<div class="adm_board_btn">
				<button type="button" id="insertBoard">저장</button>
				<!--<a href="javascript:formCheck(this)" class="admbtn_add">저장</a>-->
				<a href="javascript:formReset(this)" class="admbtn_type02">초기화</a>
				<a href="./read.php<?=$CommLink?>" class="admbtn_type03">목록</a>
			</div>

	  </div>
	</div>

	<script type="text/javascript">
		//$('input[type=checkbox], input[type=radio]').customRadioCheck();
	</script>

	</form>
		<script type="text/javascript" src="../common/smartEditor/js/HuskyEZCreator.js" charset="utf-8"></script>
		<script type="text/javascript">
		  $(function(){
			//전역변수
			var obj = [];
			//스마트에디터 프레임생성
			nhn.husky.EZCreator.createInIFrame({
				oAppRef: obj,
				elPlaceHolder: "ir1", // textarea의 name태그
				sSkinURI: "../common/smartEditor/SmartEditor2Skin.html",  // 본인 경로게 맞게 수정
				htParams : {
					// 툴바 사용 여부
					bUseToolbar : true,
					// 입력창 크기 조절바 사용 여부
					bUseVerticalResizer : true,
					// 모드 탭(Editor | HTML | TEXT) 사용 여부
					bUseModeChanger : true,
				},
				fCreator: "createSEditor2"
			});
			function pasteHTML(filepath) {
				var sHTML = '';
				oEditors.getById["ir1"].exec("PASTE_HTML", [sHTML]);
			}
			//전송버튼
			$("#insertBoard").click(function(){
				//id가 smarteditor인 textarea에 에디터에서 대입
				obj.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
				//폼 submit <- 여기부턴 유효성검사
				if(frm.subject.value == ""){
					alert('제목을 입력하세요');
					frm.subject.focus();
					return;
				}
				var content = $("#ir1").val();
				if( content == ""  || content == null || content == ' ' || content == '')  {
						alert("내용을 입력하세요.");
						oEditors.getById["ir1"].exec("FOCUS"); //포커싱
						return;
				}

				$("#insertBoardFrm").submit();
			});
		});
		</script>
