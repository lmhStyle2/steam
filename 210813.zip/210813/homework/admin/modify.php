<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['boardId']) ? $_REQUEST['boardId'] : '';
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";

if(is_empty($boardId)||is_empty($seq)) {
    echo "
    <Script>
            alert('');
            history.back();
    </Script>
    ";
    exit;
}


//#############################
$menuDepth1 = "2";
if ($boardId=='notice') {
	$menuDepth2 = "1";
}
else{
	$menuDepth2 = "2";
}
$menuDepth3 = "0";
//#############################


switch ($boardId) {
	case 'notice':
		$pageTitle = "공지사항";
		break;
	case 'press':
		$pageTitle = "보도자료";
		break;
	default :
		break;
}
$gConn = new DBConn();
$Result = BoardSql::SelectWithSeq ( $seq, $gConn->mConn );
//$ResultNextPre = BoardSql::SelectWithNextPre ( $boardId, $seq, $Result[0]->isTop, $gConn->mConn );

//$ResultI = BoardSql::FileList ($seq, $boardId, 'I', $gConn->mConn) ; // 이미지 정보 조회.
//$ResultF = BoardSql::FileList ($seq, $boardId, 'F', $gConn->mConn) ; //  파일정보 조회.

$gConn->DisConnect();



?>
<? include "../common/topmenu.php" ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.8.18/themes/base/jquery-ui.css" type="text/css" />
    
	<form action="modify_exec.php" name="frm" id="insertBoardFrm" method="post" enctype="MULTIPART/FORM-DATA">	
    <input type="hidden" name="boardId" value="<?=$boardId?>">
	<input type="hidden" name="page" value="<?=$page?>">
	<input type="hidden" name="searchKey" value="<?=$searchKey?>">
	<input type="hidden" name="searchValue" value="<?=$searchValue?>">
	<input type="hidden" name="seq" value="<?=$seq?>">
	<div class="admincontbox">
	  <div class="admincont">
			<h3>수정</h3>

			<div class="admboard-rapper mt-20">
				<table width="100%" class="adm_boarview">
					<colgroup>
						<col width="20%" />
						<col width="" />
					</colgroup>
					<tbody>
                        <tr>
                            <th scope="row">제목</th>
                            <td>
                                <input type="text" class="textform" style="width:77%;" id="subject" name="subject" value="<?=$Result[0]->subject?>"/>
                                <input type="checkbox" name="isTop" id="isTop" value="Y" class="<?if ($checkedYn=='Y') { echo 'checkbox-style2' ;}else{echo 'checkbox-style1';}?>" 
                                <?=$checked?>><label for="isTop"></label>중요
                            </td>
                        </tr>                    
                        <tr>
                            <th scope="row">내용</th>
                            <td>                                
							<textarea name="ir1" id="ir1" rows="10" cols="100" style="width:100%; height:500px; display:none;"><?=$Result[0]->content?></textarea>                                
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">공지일</th>
                            <td>
							<input type="text" class="textform" style="width:10%;" name="prDate" id="prDate" value="<?=$Result[0]->prDate?>"/>
                            </td>
                        </tr>
                        <script>
                        $(function() {
                        $( "#prDate" ).datepicker();
                        });
                        </script>														
                        <tr>
                            <th scope="row">게시여부</th>
                            <td>
                                <select id="isOpen" name="isOpen" class="selbox">
                                    <option value="Y" <?if ($Result[0]->isOpen=='Y') { echo 'selected';}?>>오픈</option>
                                    <option value="N" <?if ($Result[0]->isOpen=='N') { echo 'selected';}?>>닫음</option>
                                </select>							
                            </td>
                        </tr>
					</tbody>
				</table>
			</div>

			<div class="adm_board_btn">
                <button type="button" id="insertBoard">저장</button>
				<!--<a href="javascript:formCheck(this)" class="admbtn_add">저장</a>-->
				<a href="javascript:formReset(this)" class="admbtn_type02">초기화</a>
				<a href="read.php<?=$CommLink?>" class="admbtn_type03">목록</a>
			</div>

	  </div>
	</div>

	</form>

	
    <script type="text/javascript" src="../common/smartEditor/js/HuskyEZCreator.js" charset="utf-8"></script>
		<script type="text/javascript">
		  $(function(){
			//전역변수
			var obj = [];
			//스마트에디터 프레임생성
			nhn.husky.EZCreator.createInIFrame({
				oAppRef: obj,
				elPlaceHolder: "ir1", // textarea의 name태그
				sSkinURI: "../common/smartEditor/SmartEditor2Skin.html",  // 본인 경로게 맞게 수정
				htParams : {
					// 툴바 사용 여부
					bUseToolbar : true,
					// 입력창 크기 조절바 사용 여부
					bUseVerticalResizer : true,
					// 모드 탭(Editor | HTML | TEXT) 사용 여부
					bUseModeChanger : true,
				},
				fCreator: "createSEditor2"
			});
			function pasteHTML(filepath) {
				var sHTML = '';
				oEditors.getById["ir1"].exec("PASTE_HTML", [sHTML]);
			}
			//전송버튼
			$("#insertBoard").click(function(){
				//id가 smarteditor인 textarea에 에디터에서 대입
				obj.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
				//폼 submit <- 여기부턴 유효성검사
				if(frm.subject.value == ""){
					alert('제목을 입력하세요');
					frm.subject.focus();
					return;
				}
				var content = $("#ir1").val();
				if( content == ""  || content == null || content == ' ' || content == '')  {
						alert("내용을 입력하세요.");
						oEditors.getById["ir1"].exec("FOCUS"); //포커싱
						return;
				}

				$("#insertBoardFrm").submit();
			});
		});
		</script>