<?php
Header("Content-type: text/html; charset=utf-8");

error_reporting(E_ALL ^ E_NOTICE);


session_start();

session_destroy();

//echo "<meta http-equiv=\"refresh\" content=\"0; url=login.php\">";

echo "<Script language=javascript>"; 
echo "alert('a');";
echo "window.location='../main.php';"; 
echo "</script>";
exit;

?>