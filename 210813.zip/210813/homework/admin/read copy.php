<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
$gConn = new DBConn();
$PageLs = BoardSql::PageLs ($boardId, $pWhere, $searchKey, $searchValue, $page, 10, $gConn->mConn );
$PageTopLs = BoardSql::IsTopLs ($boardId, $pWhere, $gConn->mConn );
$gConn->DisConnect();

$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";

?>
<head>
<link rel="stylesheet" href="../css/admin.css" />
<link rel="stylesheet" href="../css/default.css" />
</head>
<script type="text/javascript">
<!--
function fn_submit() {
	/*
	if ( $('#joinNm').val() == '' ) {
		alert('성명을 입력해 주세요.');
		$('#joinNm').focus();
		return;
	}
	*/
		
	//$('#frmList').attr("action",$('#sslUrl').val());
	//alert('성명을 입력해 주세요.');
	$('#frmList').submit();
}	
//-->
</script>


<form name="frmList" id="frmList" action="<?=$pHtmlLink?>" method="post">

	<div class="admincontbox">
	  <div class="admincont">
			<h3>관리자 목록</h3>

			<div class="topsearcharea">
					<input type="text" name="searchValue" id="searchValue" value="<?=$searchValue?>" onblur="if(this.value=='')this.value='제목/내용';" onfocus="if(this.value=='');this.value='';" id="" />
					<input type="button" class="btn_search"  id="" onclick="fn_submit();"/>
			</div>
			
			<div class="total-count">
				 총 0건
			</div>

			<div class="admboard-rapper">
				<table width="100%" class="adm_boardlist">
					<colgroup>
						<col width="10%" />
						<col width="" />
						<col width="10%" />
						<col width="10%" />						
						<col width="10%" />						
						<col width="10%" />
					</colgroup>
					<thead>
					<tr>
						<th scope="col">NO</th>
						<th scope="col">제목</th>
						<th scope="col">조회수</th>
						<th scope="col">등록자</th>						
						<th scope="col">등록일자</th>
					</tr>
					</thead>
					<tbody>	
                    <?
					if(count($PageTopLs->mData)) {
						for($i=0; $i<count($PageTopLs->mData); $i++) {
					?>								
                        <tr>
                            <td>
                               
                                    공지
                            </td>
                            <td class="subject">
                            <a href="view.php<?=$CommLink?>&seq=<?=$PageTopLs->mData[$i]->seq?>&boardId=<?=$PageTopLs->mData[$i]->boardId?>&mode=read"><?=$PageTopLs->mData[$i]->subject?></a>                             
                            </td>
                            <td><?=$PageTopLs->mData[$i]->readCnt?></td>
							<td><?=$PageTopLs->mData[$i]->regId?></td>                            
                            <td><?=substr($PageTopLs->mData[$i]->regDate,0,10)?></td>                                                      
                        </tr>
                    <?
						}
					}
					?>
					
					</tbody>
				</table>
			</div>
			<div class="adm_board_btn">
				<a href="write.php?mod=write" class="admbtn_add">등록</a>
			</div>
	  </div>
	</div>
</form>