<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
$gConn = new DBConn();
$PageLs = BoardSql::PageLs ($boardId, $pWhere, $searchKey, $searchValue, $page, 10, $gConn->mConn );
$PageTopLs = BoardSql::IsTopLs ($boardId, $pWhere, $gConn->mConn );
$gConn->DisConnect();

$CommLink="?searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";

?>
<?php include "../common/topmenu.php";?>
<script type="text/javascript">
<!--
function fn_submit() {
	
	$('#frmList').submit();
}	
//-->
</script>


<form name="frmList" id="frmList" action="<?=$pHtmlLink?>" method="post">

	<div class="admincontbox">
	  <div class="admincont">
			<h3><?=$pageTitle?> 목록</h3>

			<div class="topsearcharea">
					<input type="text" name="searchValue" id="searchValue" value="<?=$searchValue?>" onblur="if(this.value=='')this.value='제목/내용';" onfocus="if(this.value=='');this.value='';" id="" />
					<input type="button" class="btn_search"  id="" onclick="fn_submit();"/>
			</div>
			
			<div class="total-count">
				 총 <?=$PageLs->mListAll?>건
			</div>

			<div class="admboard-rapper">
				<table width="100%" class="adm_boardlist">
					<colgroup>
						<col width="10%" />
						<col width="" />
						<col width="10%" />
						<col width="10%" />
						<?if ($boardId=='press'){?>
							<col width="10%" />
						<?}?>
						<col width="10%" />
					</colgroup>
					<thead>
					<tr>
						<th scope="col">NO</th>
						<th scope="col">제목 <!--<a href="#"><img src="../images/arrow.jpg" class="vertical-m" alt="" /></a>--></th>
						<th scope="col">조회수</th>
						<th scope="col">등록자</th>						
						<th scope="col">등록일자 <!--<a href="#"><img src="../images/arrow.jpg" class="vertical-m" alt="" /></a>--></th>
						
						
					</tr>
					</thead>
					<tbody>

					<?
					if(count($PageTopLs->mData)) {
						for($i=0; $i<count($PageTopLs->mData); $i++) {
					?>
							<tr>
								<td>공지</td>
								<td class="subject">
									<?if ($boardId=='notice'){?>
										<a href="view.php<?=$CommLink?>&seq=<?=$PageTopLs->mData[$i]->seq?>&boardId=<?=$PageTopLs->mData[$i]->boardId?>&mode=read"><?=$PageTopLs->mData[$i]->subject?></a>
									<?}else{?>
										<a href="view.php<?=$CommLink?>&seq=<?=$PageTopLs->mData[$i]->seq?>&boardId=<?=$PageTopLs->mData[$i]->boardId?>&mode=read"><?=$PageTopLs->mData[$i]->subject?></a>
										<!--<a href="#" onclick="fn_prview('<?=$PageTopLs->mData[$i]->boardId?>','<?=$PageTopLs->mData[$i]->seq?>');"><?=$PageTopLs->mData[$i]->subject?></a>-->
									<?}?>									
								</td>
								<td><?=$PageTopLs->mData[$i]->readCnt?></td>
								<td><?=$PageTopLs->mData[$i]->regId?></td>
								<?if ($boardId=='press'){?>
									<td><?=$PageTopLs->mData[$i]->prCom?></td>
									<td><?=substr($PageTopLs->mData[$i]->prDate,0,10)?></td>
								<?}else{?>
									<td><?=substr($PageTopLs->mData[$i]->regDate,0,10)?></td>
								<?}?>								
							</tr>
					<?
						}
					}
					?>


					<?
					if(count($PageLs->mData)) {
						$pTotal = $PageLs->mListAll;
						
						for($i=0; $i<count($PageLs->mData); $i++) {
							$RowNo = $pTotal - $PageLs->mSizePage * ($page - 1);
					?>
							<tr>
								<td>
									<?if($PageLs->mData[$i]->isTop=='Y'){?>
										공지
									<?}else{?>
										<?=$RowNo?>
									<?}?>								
								</td>
								<td class="subject">
									<?if ($boardId=='notice'){?>
										<a href="view.php<?=$CommLink?>&seq=<?=$PageLs->mData[$i]->seq?>&boardId=<?=$PageLs->mData[$i]->boardId?>&mode=read"><?=$PageLs->mData[$i]->subject?></a>
									<?}else{?>
										<a href="view.php<?=$CommLink?>&seq=<?=$PageLs->mData[$i]->seq?>&boardId=<?=$PageLs->mData[$i]->boardId?>&mode=read"><?=$PageLs->mData[$i]->subject?></a>
										<!--<a href="#" onclick="fn_prview('<?=$PageLs->mData[$i]->boardId?>','<?=$PageLs->mData[$i]->seq?>');"><?=$PageLs->mData[$i]->subject?></a>-->
									<?}?>		
								</td>
								<td><?=$PageLs->mData[$i]->readCnt?></td>
								<td><?=$PageLs->mData[$i]->regId?></td>
								<?if ($boardId=='press'){?>
									<td><?=$PageLs->mData[$i]->prCom?></td>
									<td><?=substr($PageLs->mData[$i]->prDate,0,10)?></td>
								<?}else{?>
									<td><?=substr($PageLs->mData[$i]->regDate,0,10)?></td>
								<?}?>
								
							</tr>
					<?
							$pTotal = $pTotal - 1;			//번호 desc
						}
					}
					else{
					?>
							<tr>
								<td colspan="<?=$colspan?>" align="center">조회된 데이타가 없습니다.</td>
							</tr>
					<?
					}
					?>

					</tbody>
				</table>
			</div>
			<div class="adm_board_btn">
				<a href="write.php?mod=write" class="admbtn_add">등록</a>
				<a href="./menu/admin_menu_list.php" class="admbtn_add">관리자_게시판</a>
			</div>
			<div class="paging">
			<?
			if(count($PageLs->mData)) {
				$pUrl=$_SERVER["PHP_SELF"].$PageLink;
				$PageLs->AdminPageList($pUrl);
			}     
			?>
			</div>
	  </div>
	</div>
</form>