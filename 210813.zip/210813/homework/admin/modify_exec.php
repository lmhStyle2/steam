<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?
$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['boardId']) ? $_REQUEST['boardId'] : '';

$isTop = isset($_REQUEST['isTop']) ? $_REQUEST['isTop'] : 'N';
$prDate = isset($_REQUEST['prDate']) ? $_REQUEST['prDate'] : '';
$prUrl = isset($_REQUEST['prUrl']) ? $_REQUEST['prUrl'] : '';
$prCom = isset($_REQUEST['prCom']) ? $_REQUEST['prCom'] : '';
$isOpen = isset($_REQUEST['isOpen']) ? $_REQUEST['isOpen'] : '';
$content = isset($_REQUEST['ir1']) ? $_REQUEST['ir1'] : '';

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

//echo $isTop;
//exit;

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page&seq=$seq";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page&seq=$seq";

if(is_empty($boardId)||is_empty($seq)) {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}

if($isTop=="") {
	$isTop = "N";
}

session_start();

// 디비 객체
$gBoard = new BoardSql();

$gBoard->boardId=$boardId;
$gBoard->subject=scriptHtml($subject);
$gBoard->content=$content;
//$gBoard->readCnt="0";
$gBoard->isTop=$isTop;
$gBoard->regId=$_SESSION[SS_ADM_ID];
$gBoard->regIp=$_SESSION[SS_ADM_IP];
$gBoard->isOpen=$isOpen;

$gConn = new DBConn();

$result_file = array();
$upload = array();

//****************************************************
// 이미지파일 업로드 시작.
//****************************************************
for ($i=0; $i<count($_FILES["upfile1"]["name"]); $i++) {
	$ResultFile = $gBoard->FileDetail($_REQUEST["upfile1_del_hidden"][$i], $seq, $boardId, "I", $gConn->mConn) ; // 이미지 정보 조회.

	if ($_POST["upfile1_del"][$i]){
		$upload[$i]["del_check"] = true;
	}
	else{
		$upload[$i]["del_check"] = false;
	}

	if (is_uploaded_file($_FILES["upfile1"]["tmp_name"][$i])){
		$result_file=imgUp($_FILES["upfile1"]["tmp_name"][$i], $_FILES["upfile1"]["name"][$i], UPLOAD_DIR."/board/". $boardId. "/");

		$gBoard->pSeq=$seq;
		$gBoard->attGbn="I";
		$gBoard->fileOrgNm=$result_file[0];
		$gBoard->fileSvcNm=$result_file[1];
		$gBoard->thumbNm=$result_file[3];
		$gBoard->fSize=$result_file[2];
		
		if (count($ResultFile[0])) { // 기존데이터가 있을경우 삭제 후 업데이트 처리.
			$upload[$i]["del_check"] = true;
			$gBoard->FileUpdate($_REQUEST["upfile1_del_hidden"][$i], $gConn->mConn ) ;					
		}
		else{	
			$gBoard->FileInsert( $gConn->mConn ) ;		
		}
	}
	else{
		if ($upload[$i]["del_check"] == true){
			$gBoard->FileDelete($_POST["upfile1_del_hidden"][$i], $gConn->mConn); // 디비 삭제	
		}
	}

	if ($upload[$i]["del_check"] == true){
		if (count($ResultFile[0])) {
			@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultFile[0]->fileSvcNm);
			@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultFile[0]->thumbNm);
		}
	}
	//echo $upload[$i]["del_check"] ;
	//exit;
}
//****************************************************
// 이미지파일 업로드 끝.
//****************************************************

//****************************************************
// 첨부파일 업로드 시작.
//****************************************************
for ($i=0; $i<count($_FILES["upfile2"]["name"]); $i++) {
	$ResultFile = $gBoard->FileDetail($_REQUEST["upfile2_del_hidden"][$i], $seq, $boardId, "F", $gConn->mConn) ; // 파일 정보 조회.

	if ($_POST["upfile2_del"][$i]){
		$upload[$i]["del_check"] = true;
	}
	else{
		$upload[$i]["del_check"] = false;
	}

	if (is_uploaded_file($_FILES["upfile2"]["tmp_name"][$i])){
		$result_file=fileUp($_FILES["upfile2"]["tmp_name"][$i], $_FILES["upfile2"]["name"][$i], $MAX_UPLOAD_SIZE, UPLOAD_DIR."/board/". $boardId. "/");

		$gBoard->pSeq=$seq;
		$gBoard->attGbn="F";
		$gBoard->fileOrgNm=$result_file[0];
		$gBoard->fileSvcNm=$result_file[1];
		$gBoard->thumbNm=$result_file[3];
		$gBoard->fSize=$result_file[2];
		
		if (count($ResultFile[0])) { // 기존데이터가 있을경우 삭제 후 업데이트 처리.
			$upload[$i]["del_check"] = true;
			$gBoard->FileUpdate($_REQUEST["upfile2_del_hidden"][$i], $gConn->mConn ) ;					
		}
		else{	
			$gBoard->FileInsert( $gConn->mConn ) ;		
		}
	}
	else{
		if ($upload[$i]["del_check"] == true){
			$gBoard->FileDelete($_POST["upfile2_del_hidden"][$i], $gConn->mConn); // 디비 삭제	
		}
	}

	if ($upload[$i]["del_check"] == true){
		if (count($ResultFile[0])) {
			@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultFile[0]->fileSvcNm);
			@unlink(UPLOAD_DIR."/board/". $boardId. "/".$ResultFile[0]->thumbNm);
		}
	}
	//echo $upload[$i]["del_check"] ;
	//exit;
}
//****************************************************
// 첨부파일 업로드 끝.
//****************************************************

//****************************************************
// 게시판 수정 시작
//****************************************************
$gBoard->Update($seq, $gConn->mConn ) ;
//****************************************************
// 게시판 수정 종료
//****************************************************

$gConn->DisConnect();

$pHtmlLink="read.php";
$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$pUrl=$pHtmlLink.$CommLink;

echo "<meta http-equiv='Refresh' content='0;URL=".$pUrl."'>";
?>