<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
?>
<?
$pWhere = "";
$pHtmlLink = "";

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['boardId']) ? $_REQUEST['boardId'] : '';
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

/*
if(is_empty($boardId)||is_empty($seq)) {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}
*/
//#############################
$menuDepth1 = "2";
if ($boardId=='notice') {
	$menuDepth2 = "1";
}
else{
	$menuDepth2 = "2";
}
$menuDepth3 = "0";
//#############################


switch ($boardId) {
	case 'notice':
		$pageTitle = "공지사항";
		break;
	case 'press':
		$pageTitle = "보도자료";
		break;
	default :
		break;
}


$gConn = new DBConn();
$Result = BoardSql::SelectWithSeq ( $seq, $gConn->mConn );
// $Result = BoardSql::UpdateSetReadCnt ( $seq, $gConn->mConn ); 관리자가 조회하는거는 조회수 포함 안하는게,,
//$ResultNextPre = BoardSql::SelectWithNextPre ( $boardId, $seq, $Result[0]->isTop, $gConn->mConn );

//$ResultI = BoardSql::FileList ($seq, $boardId, 'I', $gConn->mConn) ; // 이미지 정보 조회.
//$ResultF = BoardSql::FileList ($seq, $boardId, 'F', $gConn->mConn) ; //  파일정보 조회.

$gConn->DisConnect();

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";
?>


<? include "../common/topmenu.php" ?>

<script type="text/javascript">

function deleteConfirm(){
	if (confirm("삭제하시겠습니까?")){
		$('#frmWrite').attr("action","delete_exec.php");
		$('#frmWrite').submit();
	}
	return;
}	

</script>

<form name="frmWrite" id="frmWrite" action="" method="post">
<input type="hidden" name="boardId" value="<?=$boardId?>">
<input type="hidden" name="page" value="<?=$page?>">
<input type="hidden" name="searchKey" value="<?=$searchKey?>">
<input type="hidden" name="searchValue" value="<?=$searchValue?>">
<input type="hidden" name="seq" value="<?=$seq?>">

<div class="admincontbox">
  <div class="admincont">
	<h3>공지사항 상세보기</h3>

	<div class="admboard-rapper mt-20">
		<table width="100%" class="adm_boarview">
			<colgroup>
				<col width="20%" />
				<col width="" />
			</colgroup>
			<tbody>
			<tr>
				<th scope="row">제목</th>
				<td>
                    <?=$Result[0]->subject?>
				</td>
			</tr>			
            <tr>
                <th scope="row">내용</th>
                <td>

                    <!--
                    <div class="file-area">
                        <img src="../images/file_img.png" alt="" class="file-img"/>
                        <input type="button" class="file-icon" />
                    </div>
                    -->
                    <?=nl2br($Result[0]->content);?>
                </td>
            </tr>	
            <tr>
                <th scope="row">댓글                    
                </th>
                <td>                    
                    <?=nl2br($Result[0]->content);?>댓글
                </td>
            </tr>									
			<tr>
				<th scope="row">조회수</th>
				<td>
					 0
				</td>
			</tr>
			<tr>
				<th scope="row">오픈여부</th>
				<td>
					 ㅇㅅㅇ
				</td>
			</tr>
			<tr>
				<th scope="row">공지여부</th>
				<td>
					 ㅇㅅㅇ
				</td>
			</tr>
			<tr>
				<th scope="row">등록자(등록일자)</th>
				<td>
				<?=substr($Result[0]->regDate,0,10)?>
				</td>
			</tr>
		
			</tbody>
		</table>
	</div>
	

	<div class="adm_board_btn">
		<a href="modify.php<?=$CommLink?>&boardId=<?=$boardId?>&mode=modify&seq=<?=$seq?>" class="admbtn_add">수정</a>
		<a href="javascript:deleteConfirm();" class="admbtn_type04">삭제</a>
		<a href="read.php<?=$CommLink?>" class="admbtn_type03">목록</a>
	</div>
  </div>
</div>

</form>



