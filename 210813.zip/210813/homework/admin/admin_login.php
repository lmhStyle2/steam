<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");


if ( $_SESSION[SS_ADM_ID]!= "") {
	//echo "<meta http-equiv=\"refresh\" content=\"0; url=login.php\">";
	alertMsgUrl ("로그인된 사용자 입니다.", "read.php");
	exit;
}

// CSRF 취약점 대응.
$token = md5(uniqid(rand(),true));
$_SESSION['TOKEN'] = $token;

?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>웹</title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="stylesheet" href="../css/admin.css" />
<link rel="stylesheet" href="../css/default.css" />
<script src="../js/jquery-latest.js" type="text/javascript"></script>

<script language="JavaScript">
<!--
function checkForm()
{
	if ( $('#admId').val() == '' ) {
		alert('아이디를 입력해 주세요.');
		$('#admId').focus();
		return false;
	}
	
	if ( $('#admPw').val() == '' ) {
		alert('비밀번호를 입력해 주세요.');
		$('#admPw').focus();
		return false;
	}
	

	$('#frmWrite').attr("action",$('#sslUrl').val());
	$('#frmWrite').submit();
	return true;
}

function hitEnterKey(e)
{
	if(e.keyCode == 13)
	{
		checkForm();
	}
}

window.onload = function(){
	
}
//-->
</script>

</head>

<body class="loginbody">

<form class="form-2" name="frmWrite" id="frmWrite" method="post" action="user_login_exec.php" onsubmit="return checkForm();">
<input type="hidden" name="sslUrl" id="sslUrl" value="admin_login_exec.php" />
<input type="hidden" name="defaultUrl" id="defaultUrl" value="<?=$ADMIN_SITE_URL?>"/>
<input type="hidden" name="token" value="<?=$token?>">


<div id="admin_rapper">
<div class="login_topimg">
	<p>&nbsp;</p>
</div>
<div class="login-bottomarea">
	<div class="loginbox">
		<fieldset>
			<legend>로그인</legend>
			<ul class="loginform clear2">
				<li><input type="text" class="intext" placeholder="아이디" name="admId" id="admId" value=""/></li>
				<li><input type="password" class="intext"  placeholder="비밀번호" name="admPw" id="admPw" value=""/></li>
				<li><input type="submit" class="login" value="로그인" id=""/></li>
			</ul>
		</fieldset>
		<p>
		</p>
	</div>
</div>
</div>

</form>
</body>
</html>


