<?php
Header("Content-type: text/html; charset=utf-8");

error_reporting(E_ALL ^ E_NOTICE);

require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/function.php");
require_once("../include/dao/admin_user.php");

if ( $_SESSION[SS_ADM_ID]!= "") {
	//echo "<meta http-equiv=\"refresh\" content=\"0; url=login.php\">";
	alertMsgUrl ("로그인된 사용자 입니다.", "read.php");
	exit;
}

$admId = sqlInject(rejectXss($_POST['admId']));
$admPw = rejectXss($_POST['admPw']);

//$ssId =  date("Y").date("m").date("d").time(); //.session_id();
$ssId =  date("Y").date("m").date("d").time().exact_time(); //.session_id();
$admIp = getenv('REMOTE_ADDR');

// 필수항목 체크.
if (!$admId||!$admPw) {
	echo "<script language=javascript>
	alert('올바르지 않은 정보 입니다[1].');
	history.back();
	</script>";
	exit;
}

$gConn = new DBConn();
$AdminSql = new AdminSql();

$AdminSql->admId=$admId;
$AdminSql->ssId=$ssId;
$AdminSql->conIp=$admIp;
$AdminSql->admPw=$admPw;


// 로그인실패수 확인.
$Result = $AdminSql->SelectLoginFailCount($gConn->mConn);
if ($Result[0]>=5) {
	$gConn->DisConnect();
	echo "<script language=javascript>
	alert('비밀번호를 5회이상 잘못 입력하셨습니다.시스템 관리자에게 문의해 주세요.');
	history.back();
	</script>";
	exit;
}

// 중복로그인처리. 이미 로그인한 아이디정보 삭제.
$Result = $AdminSql->duplicationProc($gConn->mConn);

// 로그인 처리.
$Result = $AdminSql->SelectAdminLogin($gConn->mConn);
if (count($Result)==1) {  // 로그인 성공.

	$AdminSql->isPass='Y';
	$AdminSql->AdminLogInsert($gConn->mConn);
		
	$_SESSION[SS_ADM_ID] = $Result[0]->admId;
	$_SESSION[SS_ADM_NM] = $Result[0]->admNm;
	$_SESSION[SS_ADM_GBN] = $Result[0]->authGbn;
	$_SESSION[SS_ADM_IP] = $admIp;
	$_SESSION[SS_ADM_SEQ] = $Result[0]->seq;
	
	$_SESSION[ADM_SS_ID] = $ssId;
	
	$gConn->DisConnect();
	
	// echo"<meta http-equiv=\"refresh\" content=\"0; url=$url\">";
	//	if($conn) @mysql_close($conn);	
	echo "<Script language=javascript>"; 
	echo "window.location='./read.php';"; 
	echo "</script>";
	exit;
} 
else{
	$AdminSql->isPass='N';
	$AdminSql->AdminLogInsert($gConn->mConn);

	$gConn->DisConnect();

	echo "<script language=javascript>
		alert('올바르지 않은 정보 입니다[2].');
		history.back();
	</script>";
	exit; 
}
?>