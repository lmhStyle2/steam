<?php
session_start();

$menuCode = isset($_REQUEST['menuCode']) ? $_REQUEST['menuCode'] : $_SESSION['MENU_CODE'];

if ($menuCode==null || $menuCode==''){
	$menuCode = $_SESSION['MENU_CODE'];	
}
else{
	$_SESSION['MENU_CODE'] = $menuCode;	
}


//AdminAuthCheck('$_SERVER["SCRIPT_FILENAME"]'); // 권한체크
class LeftMenuSql
{
	var $seq ;
	var $parentSeq	;
	var $rootSeq	;
	var $level ;
	var $menuNm	;
	var $pMenuNm ;
	var $menuUrl ;
	var $fullSeq ;
	var $fullPath ;

	function leftmenu($parentSeq, $userId, $codeSeq, $pConnect) {
		
		
		$Sql .= "  SELECT  if ( t4.seq is not null , t4.seq , if ( t3.seq is not null  , t3.seq ,  if ( t2.seq is not null  , t2.seq , 1 ))) as seq, ";
		$Sql .= "	if ( t4.seq is not null , t4.parent_seq , if ( t3.seq is not null  , t3.parent_seq ,  if ( t2.seq is not null  , t2.parent_seq , 1 ))) as parent_seq, ";
		$Sql .= "	t1.seq as root_seq, ";
		$Sql .= "	if ( t4.seq is not null ,4 , if ( t3.seq is not null  , 3 ,  if ( t2.seq is not null  , 2 , 1 ))) as  lvl,  ";
		$Sql .= "	if ( t4.seq is not null , t4.menu_nm , if ( t3.seq is not null  , t3.menu_nm ,  if ( t2.seq is not null  , t2.menu_nm , 1 ))) as menu_nm, ";
		$Sql .= "	if ( t4.seq is not null , t3.menu_nm , if ( t3.seq is not null  , t2.menu_nm ,  if ( t2.seq is not null  , t1.menu_nm , '' ))) as p_menu_nm, ";
		$Sql .= "	if ( t4.seq is not null , t4.menu_url , if ( t3.seq is not null  , t3.menu_url ,  if ( t2.seq is not null  , t2.menu_url , 1 ))) as menu_url, ";
		$Sql .= "	 CONCAT_WS('>', t1.seq, t2.seq, t3.seq, t4.seq) as full_seq, ";
		$Sql .= "	CONCAT_WS(' > ', t1.menu_nm, t2.menu_nm, t3.menu_nm, t4.menu_nm) as full_path, ";
		$Sql .= "  t1.sort_num t1_sort,  t2.sort_num t2_sort,  t3.sort_num t3_sort,  t4.sort_num t4_sort ";
		$Sql .= "  FROM admin_menu AS t1 ";
		$Sql .= "        LEFT JOIN admin_menu AS t2 ON t2.parent_seq = t1.seq AND t2.is_use = 'Y' ";
		$Sql .= "        LEFT JOIN admin_menu AS t3 ON t3.parent_seq = t2.seq AND t3.is_use = 'Y' ";
		$Sql .= "        LEFT JOIN admin_menu AS t4 ON t4.parent_seq = t3.seq AND t4.is_use = 'Y' ";
		$Sql .= "  WHERE t1.parent_seq = '0' AND t1.is_use = 'Y' ";
		$Sql .= "  order by t1.sort_num, t2.sort_num, t3.sort_num, t4.sort_num ";
		


		$Sql_que = @mysqli_query($pConnect, $Sql) or die(__FILE__." : Line ".__LINE__."<p>Query : $Sql<br><br><br>".mysqli_error()) ;
		
		//echo $Sql;
		$LsResult = array();
		for($i=0; $Result=@mysqli_fetch_array($Sql_que); $i++) {
			$ResultValue[$i] = new stdClass();
			$ResultValue[$i]->seq = stripcslashes($Result["seq"]);
			$ResultValue[$i]->parentSeq = stripcslashes($Result["parent_seq"]);
			$ResultValue[$i]->rootSeq = stripcslashes($Result["root_seq"]);
			$ResultValue[$i]->level = stripcslashes($Result["lvl"]);
			$ResultValue[$i]->menuNm = stripcslashes($Result["menu_nm"]);
			$ResultValue[$i]->pMenuNm = stripcslashes($Result["p_menu_nm"]);
			$ResultValue[$i]->menuUrl = stripcslashes($Result["menu_url"]);
			$ResultValue[$i]->fullSeq = stripcslashes($Result["full_seq"]);
			$ResultValue[$i]->fullPath = stripcslashes($Result["full_path"]);
			$LsResult[$i] = $ResultValue[$i];


		}
		@mysqli_free_result($Sql_que);
		unset($Sql_que);
		return $LsResult;			
	}
}
?>

<div  id='cssmenu'>
	<ul class="lnbarea">
		
		<?
		//echo "[".$menuCode."]";
		$gConnLeft = new DBConn();
		
		$LeftMenuSql = new LeftMenuSql();
		$LeftResult = $LeftMenuSql->leftmenu(0, $_SESSION[SS_ADM_ID], '', $gConnLeft->mConn) ;
		// 1depth
		$crlf = "\r\n";
		$n = 0;

		for($i=0; $i<count($LeftResult); $i++) {
			
			$currMenu = $LeftResult[$i];
			$arrMenuSq =  explode('>' , $currMenu->fullSeq);
			$arrMenuNm =  explode('>' , $currMenu->fullPath);
			
			for($j=0;$j< count($arrMenuSq);$j++){
				
				if (  strpos($menuStr ,$arrMenuSq[$j]."|" ) > -1 )  continue;

				$menuStr .=  $arrMenuSq[$j] . "|" ;
				//echo $menuStr. ">>>" .$arrMenu[$j]."<br>\n";
				
				$_seq[$n] = $arrMenuSq[$j];
				$_name[$n] = $arrMenuNm[$j];
				$_level[$n] = $j+1;
				$_last[$n] = $j == count($arrMenuSq)-1;
				$_url[$n] = $_last[$n] ? $currMenu->menuUrl : "#";
                

				if ( $_seq[$n] == $menuCode  ) {
					$_activeMenu = $currMenu->fullSeq.">";
				}
				$n++;
			}

		}
		echo "?".$crlf;
		for ( $i = 0 ; $i < $n ; $i++ ) {
			//echo $_seq[$i] . " : " . $_name[$i]  . " : " . $_url[$i]. " : " . $_level[$i]. " : " . $_last[$i].$crlf . " : " . $_fullSeq[$i].$crlf ;
			
			$next = $i == $n-1 ? null : $i+1;

			$selectedMenu = strpos($_activeMenu,$_seq[$i] .">" ) > -1 ;

			$cssClass = "";
			if ( $_level[$i] == 1 ) {
				$cssClass = "active";
			}

			if ( $next && $_level[$next] > $_level[$i] ) {
				if ( $cssClass != "" ) $cssClass .= " "; 
				$cssClass .=  "has-sub";
			}

			if (  $selectedMenu ) {
				//if (  $_level[$i] == 1 ) {
					if ( $cssClass != "" ) $cssClass .= " "; 
					$cssClass .=  "open";
				//} else if (  $_level[$i] == 2 ) {
				//	if ( $cssClass != "" ) $cssClass .= " "; 
				//	$cssClass .=  "active";
				//}
			}

			if (  $selectedMenu && $_level[$i] > 1) {
				$cssClass .=  $cssClass == "" ? "active" : " active";
			}

			$cssText = $cssClass ? " class=\"" . $cssClass . "\" " : "";
			//if ( $_level[$i] == 1 ) $cssText = " class=\"active has-sub open\"";
			$parmaString = strpos($_url[$i], '?');
			if ($parmaString == false){ $parmaString = "?"; }
			else{ $parmaString = "&"; }

			for ( $kk = 0 ; $kk < $_level[$i]+1; $kk++ ) { echo "\t" ;}
			if ( $_last[$i] ) {
				echo "<li" . $cssText . "><a href=\"" . $_url[$i] . "\">" . $_name[$i] . "</a>";
			} else {
				echo "<li" . $cssText . "><a href=\"#\">" . $_name[$i] . "</a>";
			}

			if ( $next && $_level[$next] > $_level[$i] ) {
				echo $crlf;
				for ( $kk = 0 ; $kk < $_level[$i]+2; $kk++ ) { echo "\t" ;}
				if (  $_level[$i] == 1 ) {
					echo "<ul class=\"towdepth\" ";
					if ( $selectedMenu ) echo "style=\"display: block\" ";
					else echo "style=\"display: none\" ";
					echo ">".$crlf;
				} else if  (  $_level[$i] == 2 ) {
					echo "<ul ";
					if ( $selectedMenu ) echo "style=\"display: block\" ";
					else echo "style=\"display: none\" ";
					echo ">".$crlf;
				} else {
					echo "<ul>".$crlf;
				}
			} else if ( $next && $_level[$next] == $_level[$i] ) {
				echo "</li>".$crlf;	
			} else if ( $next && $_level[$next] < $_level[$i] ) {
				echo "</li>".$crlf;	
				for ( $kk = 0 ; $kk < ($_level[$i] - $_level[$next]) ; $kk++ ) {
					for ( $kk1 = 0 ; $kk1 < $_level[$i]; $kk1++ ) { echo "\t" ;}
					echo "	</ul>".$crlf;
					for ( $kk1 = 0 ; $kk1 < $_level[$i]; $kk1++ ) { echo "\t" ;}
					echo "</li>".$crlf;
				}
			} else if (!$next) {
				echo "</li>".$crlf;	
				for ( $kk = 0 ; $kk < ($_level[$i])-1 ; $kk++ ) {

					for ( $kk1 = 0 ; $kk1 < $_level[$i]-$kk; $kk1++ ) { echo "\t" ;}
					echo "	</ul>".$crlf;
					for ( $kk1 = 0 ; $kk1 < $_level[$i]-$kk; $kk1++ ) { echo "\t" ;}
					echo "</li>".$crlf;
				}
			}
			
		}
		
		$gConnLeft->DisConnect();
		?>
		

	

<!-- <p class="copyright">
	CopyrightⓒNEXmedia Co.,<br />
	Ltd. All Right Reserved.
</p> -->