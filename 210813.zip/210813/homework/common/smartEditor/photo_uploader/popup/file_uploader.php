<?php
// default redirection
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once("../../../../../include/common/conf.php");
require_once("../../../../../include/common/dbconn.php");
require_once("../../../../../include/common/function.php");

$url = $_REQUEST["callback"].'?callback_func='.$_REQUEST["callback_func"];
$bSuccessUpload = is_uploaded_file($_FILES['Filedata']['tmp_name']);

// SUCCESSFUL
if(bSuccessUpload) {
	$uploadDir = UPLOAD_DIR.DS."editor".DS;
	$result_file=imgUp($_FILES["Filedata"]["tmp_name"], $_FILES["Filedata"]["name"], $uploadDir, 700, 1000);

	$url .= "&bNewLine=true";
	$url .= "&sFileName=".urlencode(urlencode($result_file[1]));
	$url .= "&sFileURL=".$SITE_IMG_SVRVER_URL."/editor/".urlencode(urlencode($result_file[1]));
}
// FAILED
else {
	$url .= '&errstr=error';
}
	
header('Location: '. $url);
?>