<?php
session_start();

require_once("../../../../../include/common/conf.php");
require_once("../../../../../include/common/dbconn.php");
require_once("../../../../../include/common/function.php");
require_once("../../../../../include/dao/admin/card/class_content.php");
require_once("../../../../../include/dao/admin/card/class_card.php");

$sFileInfo = '';
$headers = array();
 
foreach($_SERVER as $k => $v) {
	if(substr($k, 0, 9) == "HTTP_FILE") {
		$k = substr(strtolower($k), 5);
		$headers[$k] = $v;
	} 
}

$test = explode(".", rawurldecode($headers['file_name']));
$name = str_replace("\0", "", time().'-'.rand(0,100).'.'.$test[1]);

$file = new stdClass;
$file->name = str_replace("\0", "", rawurldecode($name)); // ���⼭ ����
$file->size = $headers['file_size'];
$file->content = file_get_contents("php://input");

$filename_ext = strtolower(array_pop(explode('.',$file->name)));
$allow_file = array("jpg", "png", "bmp", "gif"); 

//echo $file->name;
//echo $file->content;

if(!in_array($filename_ext, $allow_file)) {
	echo "NOTALLOW_".$file->name;
} else {
	$uploadDir = UPLOAD_DIR."card/img/";
	if(!is_dir($uploadDir)){
	//	mkdir($uploadDir, 0777);
	}
	
	$newPath = $uploadDir.iconv("utf-8", "cp949", $file->name);
	
	if(file_put_contents($newPath, $file->content)) {
		$sFileInfo .= "&bNewLine=true";
		$sFileInfo .= "&sFileName=".$file->name;
		$sFileInfo .= "&sFileURL=".$SITE_URL."/upfile/card/img/".$file->name;
	}
	
	echo $sFileInfo;
}

?>