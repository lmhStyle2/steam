
<?php

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title><?=$BROWSER_TITLE?></title>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta property="og:type" content="website">
	<meta property="og:title" content="<?=$BROWSER_TITLE?>">  
	<meta property="og:description" content="<?=$BROWSER_TITLE?>">
	<meta property="og:image" content="/admin/images/og_image.png">	
	<link rel="stylesheet" href="http://lmhst.cafe24.com/homework/css/admin.css" />
	<link rel="stylesheet" href="http://lmhst.cafe24.com/homework/css/default.css" />
	<link rel="stylesheet" href="http://lmhst.cafe24.com/homework/css/reply.css" />

	<script src="http://lmhst.cafe24.com/homework/js/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="http://lmhst.cafe24.com/homework/js/jquery-ui.js" type="text/javascript"></script>	
	<script src="http://lmhst.cafe24.com/homework/js/common.js"></script>
	<script src="http://lmhst.cafe24.com/homework/js/menu.js"></script>
	<script src="http://lmhst.cafe24.com/homework/js/datepicker-ko-KR.js" type="text/javascript"></script>


	<script type="text/javascript">
	<!--
	function logOutConfirm(){
		if (confirm("로그아웃하시겠습니까?")){
			$(location).attr('href','http://lmhst.cafe24.com/homework/admin/admin_logout.php');
		}
		return;
	}		
	//-->
	</script>
</head>
<body>
<div id="admin_rapper">
	<div class="adm_header clear2">
		<div class="adm_logo"><h1><a href="/admin/main/main.php"><img src="/admin/images/adm_logo.png"  alt="" /></a></h1></div>
		<div class="adm_topright">
			<div class="topinboxarea clear2">
				<h2><?//=$SITE_NAME?></h2>
				<ul class="utilarea  clear2">
                    
                        <li>사용자님</li>
                   
					<li><a href="javascript:logOutConfirm();">로그아웃</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="adm_cont clear2">
		<div class="adm_left">
	        <ul class="lnbarea">
              <? include "leftmenu.php";?>
    
		<!-- //left side -->