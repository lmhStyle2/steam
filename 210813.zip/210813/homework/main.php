<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>웹</title>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="stylesheet" href="./css/admin.css" />
<link rel="stylesheet" href="./css/default.css" />
<script src="../js/jquery-latest.js" type="text/javascript"></script>

<script language="JavaScript">
<!--
function checkForm()
{
	if ( $('#admId').val() == '' ) {
		alert('아이디를 입력해 주세요.');
		$('#admId').focus();
		return false;
	}
	
	if ( $('#admPw').val() == '' ) {
		alert('비밀번호를 입력해 주세요.');
		$('#admPw').focus();
		return false;
	}
	

	$('#frmWrite').attr("action",$('#sslUrl').val());
	$('#frmWrite').submit();
	return true;
}

function hitEnterKey(e)
{
	if(e.keyCode == 13)
	{
		checkForm();
	}
}

window.onload = function(){
	
}
//-->
</script>

</head>

<body class="loginbody">

<form class="form-2" name="frmWrite" id="frmWrite" method="post" action="login_exec.php" onsubmit="return checkForm();">
<input type="hidden" name="sslUrl" id="sslUrl" value="login_exec.php" />
<input type="hidden" name="defaultUrl" id="defaultUrl" />

<div id="admin_rapper">
    <div class="login_topimg">
        <p>&nbsp;</p>
    </div>
    <div class="login-bottomarea">
        <div class="loginbox">
            <fieldset>
                <legend>로그인</legend>
                <ul class="loginform clear2">
                    
                    <li><a href="./admin/admin_login.php"><button type="button" class="login" value="관리자" >관리자</li>
                    <li><a href="./user/user_login.php"><button type="button" class="login" value="사용자">사용자</li>
                </ul>
            </fieldset>
            <p>
            </p>
        </div>
    </div>
</div>

</form>
</body>
</html>


