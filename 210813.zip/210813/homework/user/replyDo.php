// replyDo.php
<?php
include_once "./sql/boradSQL.php";

$boardSQL = new BoardSQL();

include_once "./_var.php";
include_once "./common/_lib.php";

$passwd = $_PDATA["passwd"];
$name = $_PDATA["name"];

// trim 은 문자열 중 빈공간을 없애는 함수입니다.
$passwd = trim($passwd); 
$name = trim($name);

$_PDATA["regdate"] = date("Y-m-d H:i:s", time());

$_PDATA["depth"] = empty($_PDATA['step']) ? 1 : 2; // depth 지정하기
$_PDATA["subject"] = $name."님 의 댓글 입니다.";  // 제목 만들어주기

if (empty($passwd)) { echo json_encode(array("type" => 100, "message" => "비밀번호를 입력해주세요.") ); }
if (empty($name)) { echo json_encode(array("type" => 100, "message" => "이름을 입력해주세요.") ); }

try {
    // json 형태로 callback
    header("Content-Type: application/json");

    $result = $boardSQL->createReply($_PDATA);  // 데이터 넣기

    if ($result["type"]) {

        $back_date = date("Y년 m월 d일 H시 i분", time());
        $contents = nl2br($_PDATA["contents"]); // 줄바꿈 필터링
        
        // 클라이언트에 콜백시킬 데이터들. 이 데이터를 가지고 리스트를 만든다.
        $callback = array(
            "name" => $name,
            "contents" => $contents,
            "rid" => $result['rid'],
            "reply" => $_PDATA["reply"],
            "depth" => $_PDATA["depth"],
            "date" => $back_date,
            "id" => $boardSQL->getLastKey()
        );

        echo json_encode(array("type" => "200", "recent" => $callback));
    } else {
        echo json_encode(array("type" => "404", $boardSQL->getError()));
    }

} catch (PDOException $e) {
    print $e->getMessage();
    die();
}
?>