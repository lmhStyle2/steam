<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/pageout.php");
require_once("../include/dao/function.php");
require_once("../include/dao/class_board.php");
require_once("../include/dao/reply_menu.php");
?>
<?
$pWhere = "";
$pHtmlLink = "";

$page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
$searchKey = isset($_REQUEST['searchKey']) ? $_REQUEST['searchKey'] : '';
$searchValue = isset($_REQUEST['searchValue']) ? $_REQUEST['searchValue'] : '';
$boardId = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$board_seq = isset($_REQUEST['board_seq']) ? $_REQUEST['board_seq'] : '';
$regId = isset($_REQUEST['regId']) ? $_REQUEST['regId'] : '';

/*
if(is_empty($boardId)||is_empty($seq)) {
      echo "
      <Script>
              alert('');
              history.back();
      </Script>
      ";
      exit;
}
*/
//#############################
$menuDepth1 = "2";
if ($boardId=='notice') {
	$menuDepth2 = "1";
}
else{
	$menuDepth2 = "2";
}
$menuDepth3 = "0";
//#############################


switch ($boardId) {
	case 'notice':
		$pageTitle = "공지사항";
		break;
	case 'press':
		$pageTitle = "보도자료";
		break;
	default :
		break;
}


$gConn = new DBConn();
$Result = BoardSql::SelectWithSeq ( $seq, $gConn->mConn );
$Result = BoardSql::UpdateSetReadCnt ( $seq, $gConn->mConn );
//$ResultNextPre = BoardSql::SelectWithNextPre ( $boardId, $seq, $Result[0]->isTop, $gConn->mConn );

//$ResultI = BoardSql::FileList ($seq, $boardId, 'I', $gConn->mConn) ; // 이미지 정보 조회.
//$ResultF = BoardSql::FileList ($seq, $boardId, 'F', $gConn->mConn) ; //  파일정보 조회.

$gConn->DisConnect();

$CommLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue&page=$page";
$PageLink="?boardId=$boardId&searchKey=$searchKey&searchValue=$searchValue";
?>


<? include "../common/topmenu.php" ?>

<script type="text/javascript">

function deleteConfirm(){
	if (confirm("삭제하시겠습니까?")){
		$('#frmWrite').attr("action","delete_exec.php");
		$('#frmWrite').submit();
	}
	return;
}	


function formMod(){
				
    $('#frmMod').submit(); 
}

function formCheck(thisForm){
				
	if ( $('#pw').val() == '' ) {
		alert('비밀번호를 입력해 주세요.');
		$('#pw').focus();
		return;
	}		
	if ( $('#content').val() == '' ) {
		alert('내용을 입력해 주세요.');
		$('#content').focus();
		return;
	}

	$('#frmWrite').submit();
}

function load(url){
    //window = new Window(); //window라는 객체가 미리 생성
    window.open(url,"myWindow","left=100,top=100,width=400,height=150") 
    //url오픈, "myWindow"창의 이름
}



</script>


<div class="admincontbox">
  <div class="admincont">
	<h3>공지사항 상세보기</h3>
    <?php
    echo "seq=".$seq."<br>";
    ?>
	<div class="admboard-rapper mt-20">
		<table width="100%" class="adm_boarview">
			<colgroup>
				<col width="20%" />
				<col width="" />
			</colgroup>
			<tbody>
			<tr>
				<th scope="row">제목</th>
				<td>
                    <?=$Result[0]->subject?>
				</td>
			</tr>			
            <tr>
                <th scope="row">내용</th>
                <td>

                    <!--
                    <div class="file-area">
                        <img src="../images/file_img.png" alt="" class="file-img"/>
                        <input type="button" class="file-icon" />
                    </div>
                    -->
                    <?=nl2br($Result[0]->content);?>
                </td>
            </tr>	
            <tr>
                <th >댓글                    
                </th>
				<td>
						
                    <!--댓글 -->                	
					<div class="reply_view">
						<h3>댓글목록</h3>						                          
                        <!-- 댓글 불러오기 -->
                        <?php                            
                            $gConn = new DBConn();									
                            $replyLs = ReplyMenuSql::replyLs ($seq, $gConn->mConn );
                            $gConn->DisConnect();									
                        ?>
                        <?php
                            for($i=0; $i<count($replyLs->mData); $i++) {
                        ?>
                        <form name="frmMod" id="frmMod" action="reply_modify.php" method="post">  		 
                        <div class="dap_lo">
                            <input type="hidden" name="reply_seq" id="reply_seq" value="<?=$replyLs->mData[$i]->seq?>">
                            <?=$replyLs->mData[$i]->seq?>
                            <div><b><?=$replyLs->mData[$i]->regId?></b></div>
                            <div class="dap_to comt_edit"><?=$replyLs->mData[$i]->content?></div>
                            <div class="rep_me dap_to"><?php echo "2021.08.11"; ?></div>
                            <div class="rep_me rep_menu">                               
                                <a href="javascript:load('./reply_modify.php?seq=<?=$replyLs->mData[$i]->seq?>')">수정</a>					
                                <a href="javascript:load('./reply_delete_exec.php?seq=<?=$replyLs->mData[$i]->seq?>')">삭제</a>
                            </div>                                        
                        <!-- 댓글 불러오기 끝 -->
                        </div>
                        </form>
                        <?
                        }
                        ?>                                                
                        <!--- 댓글 입력 폼 --> 
                        <form name="frmWrite" id="frmWrite" action="reply_exec.php" method="post">  
                        <div class="dap_ins">  
                            <input type="hidden" name="isUse" id="isUse" value="Y" />
                            <input type="hidden" name="board_seq" id="board_seq" value="<?=$seq?>" />
                            <input type="password" name="pw" id="pw" class="dat_pw" size="15" placeholder="비밀번호">
                            <div style="margin-top:10px; ">
                                <textarea name="content" class="reply_content" id="content" ></textarea>
                                <a href="javascript:" onclick="formCheck(this);" class="admbtn_add">댓글</a>
                            </div>							
                        </div>
                        </form>
                        <!--- 댓글 입력 폼 끝-->
					</div>
					<!--- 댓글 불러오기 끝 -->
				</td>
            </tr>									
			<tr>
				<th scope="row">조회수</th>
				<td>
					 0
				</td>
			</tr>
			<?php
				if($auth_gbn !=""){
			?>
			<tr>
				<th scope="row">오픈여부</th>
				<td>
					 ㅇㅅㅇ
				</td>
			</tr>
			<tr>
				<th scope="row">공지여부</th>
				<td>
					 ㅇㅅㅇ
				</td>
			</tr>
			<?}?>
			<tr>
				<th scope="row">등록자(등록일자)</th>
				<td>
				<?=substr($Result[0]->regDate,0,10)?>
				</td>
			</tr>
		
			</tbody>
		</table>
	</div>
	
	<?php
		if($auth_gbn !=""){
	?>
	<div class="adm_board_btn">
		<a href="modify.php<?=$CommLink?>&boardId=<?=$boardId?>&mode=modify&seq=<?=$seq?>" class="admbtn_add">수정</a>
		<a href="javascript:deleteConfirm();" class="admbtn_type04">삭제</a>
		<a href="read.php<?=$CommLink?>" class="admbtn_type03">목록</a>
	</div>
	<?}else{?>
	<div class="adm_board_btn">		
		<a href="read.php<?=$CommLink?>" class="admbtn_type03">목록</a>
	</div>
	<?}?>
  </div>
</div>





