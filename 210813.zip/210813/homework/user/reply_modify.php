<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/function.php");
require_once("../include/dao/admin_menu.php");
require_once("../include/dao/reply_menu.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<link rel="stylesheet" href="http://lmhst.cafe24.com/homework/css/reply.css" />
<?
echo "현재 로그인 : ".$_SESSION[SS_USER_ID];

$seq = $_GET["seq"];

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

$seq = sqlInject(rejectXss($seq));

$gConn = new DBConn();
$Result = ReplyMenuSql::SelectWithSeq($seq, $gConn->mConn);
$gConn->DisConnect();
?>
<?php                            
  if($_SESSION[SS_USER_ID] != $Result[0]->regId){
    echo "<script language='javascript'>"; 
    echo "alert('수정권한이 없습니다.');"; 
    echo "</script>";
    exit;
  }
?>
<script src="http://lmhst.cafe24.com/homework/js/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="http://lmhst.cafe24.com/homework/js/jquery-ui.js" type="text/javascript"></script>	
	<script src="http://lmhst.cafe24.com/homework/js/common.js"></script>
	<script src="http://lmhst.cafe24.com/homework/js/menu.js"></script>
	<script src="http://lmhst.cafe24.com/homework/js/datepicker-ko-KR.js" type="text/javascript"></script>

<script type="text/javascript">
function formCheck(obj)
{    
    $('#frmWrite').attr("action","reply_modify_exec.php");
    $('#frmWrite').submit();
}

</script>

<form action="reply_modify_exec.php" name="frmWrite" id="frmWrite" method="post" enctype="MULTIPART/FORM-DATA">
<input type="hidden" name="seq" value="<?=$seq?>">
<?php echo "seq확인".$seq."<br>" ?>
<div><b><?=$Result[0]->regId?></b></div>
<div class="dap_to comt_edit">
    <textarea name="content" class="reply_content" id="content" ><?=$Result[0]->content?></textarea>
</div>
<div class="rep_me dap_to"><?php echo "2021.08.11"; ?></div>
<div class="rep_me rep_menu">
    <a href="javascript:formCheck(this)" class="admbtn_add">저장</a>    
    <a href="javascript:" onclick="formCheck(this);" class="dat_delete_bt" href="#">취소</a>
</div>
</form>