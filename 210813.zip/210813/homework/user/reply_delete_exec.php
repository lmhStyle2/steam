<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/function.php");
require_once("../include/dao/admin_menu.php");
require_once("../include/dao/reply_menu.php");

?>
<?
// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?

$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';

$gConn = new DBConn();
$Result = ReplyMenuSql::SelectWithSeq($seq, $gConn->mConn);
$gConn->DisConnect();

if(is_empty($_SESSION[SS_USER_ID])||is_empty($Result[0]->regId)) {
      echo "
      <Script>
            alert('삭제권한이 없습니다.');
            history.back();
      </Script>
      ";
      exit;
}

// 디비 객체
$gBoard = new ReplyMenuSql();
$gConn = new DBConn();

$gBoard->ReplyDelete($seq, $gConn->mConn ) ;

$gConn->DisConnect();
$msg = "삭제되었습니다";

echo "<script language='javascript'>"; 
echo "alert('".$msg."');"; 
echo "window.opener.location.reload();"; 
echo "self.close();"; 
echo "</script>";


alertMsgUrl("삭제되었습니다.", "$pUrl");
?>