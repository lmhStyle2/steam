<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/function.php");
require_once("../include/dao/admin_menu.php");
require_once("../include/dao/reply_menu.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?


$seq = isset($_REQUEST['board_seq']) ? $_REQUEST['board_seq'] : '';

$board_seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$is_use = isset($_REQUEST['is_use']) ? $_REQUEST['is_use'] : '';
$content = isset($_REQUEST['content']) ? $_REQUEST['content'] : '';
$pw = isset($_REQUEST['pw']) ? $_REQUEST['pw'] : '';
$regId = isset($_REQUEST['regId']) ? $_REQUEST['regId'] : '';
$reg_ip = isset($_REQUEST['reg_ip']) ? $_REQUEST['reg_ip'] : '';
$mod_date = isset($_REQUEST['mod_date']) ? $_REQUEST['mod_date'] : '';
$mod_id = isset($_REQUEST['mod_id']) ? $_REQUEST['mod_id'] : '';
$mod_ip = isset($_REQUEST['mod_ip']) ? $_REQUEST['mod_ip'] : '';


$rdoKind = sqlInject(rejectXss($rdoKind));
$seq = sqlInject(rejectXss($seq));
$board_seq = sqlInject(rejectXss($board_seq));
$content = sqlInject(rejectXss($content));
$pw = sqlInject(rejectXss($pw));
$mode = sqlInject(rejectXss($mode));
$regId = sqlInject(rejectXss($regId));


//echo "<br>content = ".$content;

/*
if (!(isset($_SESSION['TOKEN']) && $_POST['token'] == $_SESSION['TOKEN'])){
	echo " 비정상적인 접근 ";
	exit;
}
*/

$gConn = new DBConn();

// 디비 객체
$gBoard = new ReplyMenuSql();

$gBoard->seq=$seq;
$gBoard->pw=$pw;
$gBoard->board_seq=$board_seq;
$gBoard->content=$content;
$gBoard->isUse=$isUse;
$gBoard->regId=$_SESSION[SS_USER_ID];


$gConn = new DBConn();
$maxSeq = $gBoard->SelectMaxSeq( $gConn->mConn ) ;
$gBoard->Insert($maxSeq, $gConn->mConn ) ;


$msg = '등록되었습니다.';
$gConn->DisConnect();

echo "<script language='javascript'>"; 
echo "alert('".$msg."');"; 
echo "location.href='./view.php?seq=$seq';"; 
echo "</script>";
exit;

?>