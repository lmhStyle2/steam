<?php
require_once("../include/dao/conf.php");
require_once("../include/dao/dbconn.php");
require_once("../include/dao/function.php");
require_once("../include/dao/admin_menu.php");
require_once("../include/dao/reply_menu.php");

// ##########################################################
// 회원권한조회
// ##########################################################
$thisPageAuthrityMethod = array("S");
require_once("../include/dao/page_authority.php");
?>
<?php
$isUse = 'Y';
$seq = isset($_REQUEST['seq']) ? $_REQUEST['seq'] : '';
$content = isset($_REQUEST['content']) ? $_REQUEST['content'] : '';

$gBoard = new ReplyMenuSql();
$gBoard->seq=$seq;
$gBoard->content=$content;
$gBoard->isUse=$isUse;
$gBoard->seq=$seq;
$gBoard->regId=$_SESSION[SS_USER_ID];

$gConn = new DBConn();
$gBoard->ReplyMenuEdit($seq, $gConn->mConn ) ;

$msg = '수정완료';

echo "<script language='javascript'>"; 
echo "alert('".$msg."');"; 
echo "window.opener.location.reload();"; 
echo "self.close();"; 
echo "</script>";
exit;